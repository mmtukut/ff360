const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Access your API key as an environment variable
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-pro"});

router.post('/chat', async (req, res) => {
  console.log('Request body:', req.body);
  try {
    const { messages, propertyContext, infrastructureContext } = req.body;

    const systemMessage = {
      role: "system",
      content: `You are FastFind AI, a helpful real estate assistant. You have access to the following property data:
        ${JSON.stringify(propertyContext)}
        
        And infrastructure data:
        ${JSON.stringify(infrastructureContext)}
        
        Provide concise, relevant responses about properties and infrastructure based on this data.
        For prices, use the ₦ symbol and format large numbers with commas.
        Always mention specific properties and their details when relevant.`
    };

    const chat = model.startChat({
      history: [...messages.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: msg.content
      })),
      ],
      generationConfig: {
        maxOutputTokens: 500,
      },
    });

    const result = await chat.sendMessage(systemMessage.content);
    const response = await result.response;

    res.json({ response: response.text() });
  } catch (error) {
    console.error('Error processing chat:', error);
    res.status(500).json({ error: 'Error processing chat request' });
  }
});

module.exports = router; 