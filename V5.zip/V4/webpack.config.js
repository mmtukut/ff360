import { createClient } from '@redis/client';
require('dotenv').config();
const natural = require('natural');
const { Client } = require('pg');
const pgpass = require('pgpass');
const memjs = require('memjs');
const sylvester = require('sylvester');
const wordnet = require('wordnet-db');
const split2 = require('split2');