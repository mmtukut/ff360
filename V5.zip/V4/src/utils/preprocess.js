import nlp from 'compromise';
import glove from '../data/glove.json'; // Import the GloVe model
import natural from 'natural';
import { removeStopwords } from 'stopword';

const tokenizer = new natural.WordTokenizer();
const lemmatizer = new natural.WordNetLemmatizer();

const preprocess = (text) => {
  // 1. Tokenize the text
  let tokens = tokenizer.tokenize(text.toLowerCase());

  // 2. Remove punctuation and numerical values
  tokens = tokens.map(token => token.replace(/[^a-zA-Z]/g, ''));

  // 3. Remove empty tokens
  tokens = tokens.filter(token => token !== '');

  // 4. Remove stop words
  tokens = removeStopwords(tokens);

  // 5. Lemmatize the tokens
  tokens = tokens.map(token => lemmatizer.lemmatize(token)[0]);

  return tokens;
};

const getWordEmbedding = (token) => {
  if (glove[token]) {
    return glove[token];
  } else {
    // Return a zero vector if the token is not found
    return Array(50).fill(0); // Assuming 50 dimensions for the GloVe model
  }
};

export { preprocess, getWordEmbedding }; 