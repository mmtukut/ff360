import * as tf from '@tensorflow/tfjs';

const createModel = (embeddingDimension, sequenceLength, numIntents, vocabularyLength) => {
  const model = tf.sequential();

  // 1. Embedding layer
  model.add(tf.layers.embedding({
    inputDim: vocabularyLength, // Vocabulary size
    outputDim: embeddingDimension,
    inputLength: sequenceLength
  }));

  // 2. Flatten layer
  model.add(tf.layers.flatten());

  // 3. Dense layer for classification
  model.add(tf.layers.dense({
    units: numIntents,
    activation: 'softmax' // Use softmax for multi-class classification
  }));

  // Compile the model
  model.compile({
    optimizer: 'adam', // Use the Adam optimizer
    loss: 'categoricalCrossentropy', // Use categorical crossentropy for multi-class classification
    metrics: ['accuracy'] // Track accuracy during training
  });

  return model;
};

export default createModel; 