import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Layers, X, ChevronLeft, ChevronRight, 
  Heart, Share2, Star, Info, 
  MapPin, Building, DollarSign, TrendingUp, 
  Search, SlidersHorizontal, Home, Building2, Briefcase, Crown, Factory, BedDouble, Map, Bath, Square, ArrowLeft,
  Satellite, 
  Sun, 
  Moon, 
  Mountain, 
  Navigation, 
  Compass, 
  Locate,
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize
} from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import Supercluster from 'supercluster';
import SearchInterface from './SearchInterface';
import { toast } from 'react-hot-toast';
import { LoadingSpinner } from './common/LoadingSpinner';
import AdvancedFilters from './AdvancedFilters';

const propertyTypes = [
  { id: 'all', label: 'All', icon: Building },
  { id: 'homes', label: 'Homes', icon: Home },
  { id: 'apts', label: 'Apts', icon: Building2 },
  { id: 'office', label: 'Office', icon: Briefcase },
  { id: 'luxury', label: 'Luxury', icon: Crown },
  { id: 'industrial', label: 'Industrial', icon: Factory },
  { id: 'hotels', label: 'Hotels', icon: BedDouble },
  { id: 'land', label: 'Land', icon: Map },
];

const priceRanges = [
  { id: 'any', label: 'Any Price' },
  { id: '0-50m', label: '₦0 - ₦50M' },
  { id: '50m-100m', label: '₦50M - ₦100M' },
  { id: '100m-200m', label: '₦100M - ₦200M' },
  { id: '200m+', label: '₦200M+' }
];

const bedroomOptions = [
  { id: 'any', label: 'Any' },
  { id: '1', label: '1' },
  { id: '2', label: '2' },
  { id: '3', label: '3' },
  { id: '4', label: '4+' }
];

const mapStyles = [
  {
    id: 'streets',
    name: 'Streets',
    url: 'mapbox://styles/mapbox/streets-v12',
    icon: Map
  },
  {
    id: 'satellite',
    name: 'Satellite',
    url: 'mapbox://styles/mapbox/satellite-streets-v12',
    icon: Satellite
  },
  {
    id: 'light',
    name: 'Light',
    url: 'mapbox://styles/mapbox/light-v11',
    icon: Sun
  },
  {
    id: 'dark',
    name: 'Dark',
    url: 'mapbox://styles/mapbox/dark-v11',
    icon: Moon
  },
  {
    id: 'outdoors',
    name: 'Outdoors',
    url: 'mapbox://styles/mapbox/outdoors-v12',
    icon: Mountain
  }
];

const MapView = ({ properties = [], onClose, filters: initialFilters }) => {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [mapStyle, setMapStyle] = useState('light');
  const [showLayerOptions, setShowLayerOptions] = useState(false);
  const [activeCluster, setActiveCluster] = useState(null);
  const [heatmapVisible, setHeatmapVisible] = useState(false);
  const [viewMode, setViewMode] = useState('split'); // 'split', 'full-map', 'full-list'
  const [activeFilter, setActiveFilter] = useState('all');
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);
  const [selectedPrice, setSelectedPrice] = useState('any');
  const [selectedBedrooms, setSelectedBedrooms] = useState('any');
  const [selectedAmenities, setSelectedAmenities] = useState([]);
  const navigate = useNavigate();
  const [supercluster, setSupercluster] = useState(null);
  const [showStyleSelector, setShowStyleSelector] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  const [isLocating, setIsLocating] = useState(false);
  const [bearing, setBearing] = useState(0);
  const [showControls, setShowControls] = useState(false);
  const [showPropertyTypes, setShowPropertyTypes] = useState(false);
  const [showZoomControls, setShowZoomControls] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [show3DBuildings, setShow3DBuildings] = useState(true);
  const [show3DMap, setShow3DMap] = useState(true);
  const [filterValues, setFilterValues] = useState({
    propertyType: [],
    priceRange: { min: '', max: '' },
    bedrooms: '',
    bathrooms: '',
    amenities: [],
    furnished: false,
    availability: '',
    propertyAge: '',
    parkingSpots: '',
    floorLevel: '',
    facing: '',
    petsAllowed: false,
    securityFeatures: [],
    nearbyFacilities: [],
    distanceTo: {
      schools: '',
      hospitals: '',
      shopping: '',
      transport: ''
    }
  });

  // Update map style when it changes
  useEffect(() => {
    if (map.current) {
      const selectedStyle = mapStyles.find(style => style.id === mapStyle);
      if (selectedStyle) {
        map.current.setStyle(selectedStyle.url);
      }
    }
  }, [mapStyle]);

  // Main map initialization effect
  useEffect(() => {
    if (!mapContainer.current || !properties?.length) return;

    mapboxgl.accessToken = 'pk.eyJ1IjoibW10dWt1ciIsImEiOiJjbTEyZGk2dmwwbjZyMmtzMXFzb3V0cHRuIn0.pDgNHWd_o6u2NKVFib0EPQ';
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [7.491, 9.082],
      zoom: 12,
      pitch: 45,
      bearing: -17.6,
      antialias: true
    });

    // Initialize Supercluster
    const cluster = new Supercluster({
      radius: 40,
      maxZoom: 16,
      minPoints: 2 // Minimum points to form a cluster
    });

    // Format properties for clustering
    const points = properties.map(property => ({
      type: 'Feature',
      properties: {
        ...property,
        priceNum: parseInt(property.price.replace(/[₦,]/g, '')) / 1000000
      },
      geometry: {
        type: 'Point',
        coordinates: property.coordinates
      }
    }));

    cluster.load(points);
    setSupercluster(cluster);

    map.current.on('load', () => {
      // Update clusters on map move
      const updateClusters = () => {
        // Helper functions inside updateClusters where cluster is available
        const calculateClusterTrend = (clusterProperties) => {
          if (!cluster || !clusterProperties) return 0;

          if (clusterProperties.cluster_id) {
            try {
              const leaves = cluster.getLeaves(clusterProperties.cluster_id);
              const growthValues = leaves
                .map(leaf => leaf.properties.growth)
                .filter(Boolean);
              
              if (!growthValues.length) return 0;
              return growthValues.reduce((sum, val) => sum + val, 0) / growthValues.length;
            } catch (error) {
              console.error('Error calculating cluster trend:', error);
              return 0;
            }
          }
          
          return clusterProperties.growth || 0;
        };

        const getClusterTrend = (clusterProperties) => {
          const trend = calculateClusterTrend(clusterProperties);
          if (trend > 5) return '🔥';
          if (trend > 0) return '📈';
          return '';
        };

        const getClusterSize = (count) => {
          if (count < 5) return 'small';
          if (count < 10) return 'medium';
          return 'large';
        };

        const bounds = map.current.getBounds();
        const zoom = Math.floor(map.current.getZoom());
        
        const clusters = cluster.getClusters(
          [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()],
          zoom
        );

        // Remove existing markers

        clusters.forEach(clusterPoint => {
          const el = document.createElement('div');

          if (clusterPoint.properties.cluster) {
            // Cluster marker
            const pointCount = clusterPoint.properties.point_count;
            const leaves = cluster.getLeaves(clusterPoint.properties.cluster_id);
            const avgPrice = leaves.reduce((sum, leaf) => {
              const price = parseInt(leaf.properties.price.replace(/[₦,]/g, '')) / 1000000;
              return sum + price;
            }, 0) / pointCount;
            
            el.innerHTML = `
              <div class="cluster-marker-${getClusterSize(pointCount)}">
                <span class="cluster-count">${pointCount}</span>
                <span class="cluster-price">Avg: ₦${avgPrice.toFixed(1)}M</span>
                ${getClusterTrend(clusterPoint.properties)}
              </div>
            `;

            // Add cluster popup
            new mapboxgl.Marker(el)
              .setLngLat(clusterPoint.geometry.coordinates)
              .setPopup(
                new mapboxgl.Popup({ offset: 25 })
                  .setHTML(`
                    <div class="p-4">
                      <h3 class="font-bold text-lg mb-2">${pointCount} Properties</h3>
                      <div class="space-y-2">
                        ${leaves.slice(0, 3).map(point => `
                          <div class="cursor-pointer hover:bg-gray-50 p-2 rounded" 
                               onclick="window.location.href='/properties/${point.properties.id}'">
                            <div class="font-medium">${point.properties.title}</div>
                            <div class="text-sm text-gray-600">₦${point.properties.priceNum}M</div>
                          </div>
                        `).join('')}
                        ${leaves.length > 3 ? `
                          <div class="text-sm text-gray-500 pt-2 border-t">
                            +${leaves.length - 3} more properties
                          </div>
                        ` : ''}
                      </div>
                    </div>
                  `)
              )
              .addTo(map.current);
          } else {
            // Single property marker
            el.innerHTML = `
              <div class="price-tag-container">
                <div class="price-tag ${getPropertyClass(clusterPoint.properties)}">
                  <div class="price-main">
                    ₦${clusterPoint.properties.priceNum}M
                  </div>
                  <div class="price-details">
                    ${clusterPoint.properties.beds ? `${clusterPoint.properties.beds}bed` : ''} 
                    ${clusterPoint.properties.area ? `· ${clusterPoint.properties.area}` : ''}
                    ${clusterPoint.properties.type === 'luxury' ? '⭐' : ''}
                  </div>
                  ${clusterPoint.properties.investment_score ? `
                    <div class="investment-badge ${getInvestmentScoreClass(clusterPoint.properties.investment_score)}">
                      ${getInvestmentLabel(clusterPoint.properties.investment_score)}
                    </div>
                  ` : ''}
                </div>
              </div>
            `;

            new mapboxgl.Marker(el)
              .setLngLat(clusterPoint.geometry.coordinates)
              .setPopup(
                new mapboxgl.Popup({ offset: 25 })
                  .setHTML(`
                    <div class="p-3 cursor-pointer" onclick="window.location.href='/properties/${clusterPoint.properties.id}'">
                      <img src="${clusterPoint.properties.image}" class="w-full h-32 object-cover rounded-lg mb-2" />
                      <div class="flex items-center justify-between mb-1">
                        <h3 class="font-bold text-gray-900">${clusterPoint.properties.title}</h3>
                        ${clusterPoint.properties.type === 'luxury' ? '<span class="verified-badge">✓ Premium</span>' : ''}
                      </div>
                      <p class="text-sm text-gray-600 mb-2">${clusterPoint.properties.location}</p>
                      ${clusterPoint.properties.description ? `
                        <p class="text-sm text-gray-600 mt-2">${clusterPoint.properties.description}</p>
                      ` : ''}
                      ${clusterPoint.properties.growth ? `
                        <div class="mt-2 flex items-center gap-1 text-green-600 text-sm">
                          <span>📈</span> +${clusterPoint.properties.growth}% growth/year
                        </div>
                      ` : ''}
                    </div>
                  `)
              )
              .addTo(map.current);
          }
        });
      };

      map.current.on('moveend', updateClusters);
      updateClusters();

      // Add 3D building layer
      map.current.addLayer({
        'id': '3d-buildings',
        'source': 'composite',
        'source-layer': 'building',
        'filter': ['==', 'extrude', 'true'],
        'type': 'fill-extrusion',
        'minzoom': 14,
        'paint': {
          'fill-extrusion-color': '#aaa',
          'fill-extrusion-height': [
            'interpolate',
            ['linear'],
            ['zoom'],
            15,
            0,
            15.05,
            ['get', 'height']
          ],
          'fill-extrusion-base': [
            'interpolate',
            ['linear'],
            ['zoom'],
            15,
            0,
            15.05,
            ['get', 'min_height']
          ],
          'fill-extrusion-opacity': 0.6
        }
      });

      // Maintain 3D buildings when style changes
      map.current.on('style.load', () => {
        if (!map.current.getLayer('3d-buildings')) {
          map.current.addLayer({
            'id': '3d-buildings',
            'source': 'composite',
            'source-layer': 'building',
            'filter': ['==', 'extrude', 'true'],
            'type': 'fill-extrusion',
            'minzoom': 14,
            'paint': {
              'fill-extrusion-color': '#aaa',
              'fill-extrusion-height': [
                'interpolate',
                ['linear'],
                ['zoom'],
                15,
                0,
                15.05,
                ['get', 'height']
              ],
              'fill-extrusion-base': [
                'interpolate',
                ['linear'],
                ['zoom'],
                15,
                0,
                15.05,
                ['get', 'min_height']
              ],
              'fill-extrusion-opacity': 0.6
            }
          });
        }
      });

      // Add property markers with enhanced styling
      properties.forEach(property => {
        const el = document.createElement('div');
        el.className = 'property-marker';
        
        // Format price by removing "₦" and "," and converting to number
        const priceNumber = parseInt(property.price.replace(/[₦,]/g, '')) / 1000000;
        
        el.innerHTML = `
          <div class="price-tag-container">
            <div class="price-tag">
              <div class="price-main">
                ₦${priceNumber}M
              </div>
              <div class="price-details">
                ${property.beds ? `${property.beds}bed` : ''} 
                ${property.area ? `· ${property.area}` : ''}
                ${property.type === 'luxury' ? '⭐' : ''}
              </div>
              ${property.investment_score ? `
                <div class="investment-badge ${getInvestmentScoreClass(property.investment_score)}">
                  ${getInvestmentLabel(property.investment_score)}
                </div>
              ` : ''}
            </div>
          </div>
        `;

        // Helper functions for investment scoring
        function getInvestmentScoreClass(score) {
          if (score >= 8) return 'hot-investment';
          if (score >= 6) return 'good-investment';
          return 'normal-investment';
        }

        function getInvestmentLabel(score) {
          if (score >= 8) return '🔥 Hot Area';
          if (score >= 6) return '📈 Growing';
          return '💡 Potential';
        }

        const popup = new mapboxgl.Popup({ offset: 25 })
          .setHTML(`
            <div class="p-3 cursor-pointer property-popup" data-property-id="${property.id}">
              <img src="${property.image}" class="w-full h-32 object-cover rounded-lg mb-2" />
              <div class="flex items-center justify-between mb-1">
                <h3 class="font-bold text-gray-900">${property.title}</h3>
                ${property.verified ? '<span class="verified-badge">✓ Verified</span>' : ''}
              </div>
              <p class="text-sm text-gray-600 mb-2">${property.location}</p>
              <div class="flex items-center justify-between">
                <span class="text-xl font-bold">${property.price}</span>
                <div class="flex items-center gap-2">
                  ${property.growth ? `<span class="text-green-600 text-sm">+${property.growth}% /yr</span>` : ''}
                </div>
              </div>
              <div class="flex items-center gap-4 mt-2 text-sm text-gray-600">
                ${property.beds ? `
                  <div class="flex items-center gap-1">
                    <BedDouble className="h-4 w-4" />
                    ${property.beds} Beds
                  </div>
                ` : ''}
                ${property.baths ? `
                  <div class="flex items-center gap-1">
                    <Bath className="h-4 w-4" />
                    ${property.baths} Baths
                  </div>
                ` : ''}
                ${property.area ? `
                  <div class="flex items-center gap-1">
                    <Square className="h-4 w-4" />
                    ${property.area}
                  </div>
                ` : ''}
              </div>
            </div>
          `);

        // Add click event listener to popup
        popup.on('open', () => {
          const popupElement = document.querySelector('.property-popup');
          if (popupElement) {
            popupElement.addEventListener('click', () => {
              navigate(`/properties/${property.id}`);
            });
          }
        });

        new mapboxgl.Marker(el)
          .setLngLat(property.coordinates)
          .setPopup(popup)
          .addTo(map.current);
      });

      // Add after map initialization
      map.current.on('rotate', () => {
        setBearing(map.current.getBearing());
      });
    });

    return () => map.current.remove();
  }, [properties, navigate]);

  // Separate effect for handling user location
  useEffect(() => {
    if (!map.current || !userLocation) return;

    const el = document.createElement('div');
    el.className = 'user-location-marker';
    
    new mapboxgl.Marker({
      element: el,
      anchor: 'center'
    })
      .setLngLat(userLocation)
      .addTo(map.current);

    // Add accuracy radius
    map.current.addSource('user-location', {
      type: 'geojson',
      data: {
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: userLocation
        }
      }
    });

    map.current.addLayer({
      id: 'user-location-accuracy',
      type: 'circle',
      source: 'user-location',
      paint: {
        'circle-radius': 70,
        'circle-color': '#4dabf7',
        'circle-opacity': 0.2,
        'circle-stroke-width': 1,
        'circle-stroke-color': '#339af0'
      }
    });

    return () => {
      if (map.current.getLayer('user-location-accuracy')) {
        map.current.removeLayer('user-location-accuracy');
      }
      if (map.current.getSource('user-location')) {
        map.current.removeSource('user-location');
      }
    };
  }, [userLocation]);

  // Helper functions
  const getClusterSize = count => {
    if (count < 5) return 'small';
    if (count < 10) return 'medium';
    return 'large';
  };

  const calculateClusterTrend = (clusterProperties) => {
    // For a cluster, we need to get the leaves (actual properties)
    if (clusterProperties.cluster_id) {
      const leaves = supercluster.getLeaves(clusterProperties.cluster_id);
      const growthValues = leaves
        .map(leaf => leaf.properties.growth)
        .filter(Boolean);
      
      if (!growthValues.length) return 0;
      return growthValues.reduce((sum, val) => sum + val, 0) / growthValues.length;
    }
    
    // For single property
    return clusterProperties.growth || 0;
  };

  const getClusterTrend = (clusterProperties) => {
    const trend = calculateClusterTrend(clusterProperties);
    if (trend > 5) return '🔥';
    if (trend > 0) return '📈';
    return '';
  };

  const getPropertyClass = property => {
    if (property.investment_score >= 8) return 'hot-property';
    if (property.investment_score >= 6) return 'good-property';
    return 'normal-property';
  };

  const getInvestmentBadge = (property) => {
    if (!property.investment_score) return '';
    
    return `
      <div class="investment-badge ${getInvestmentScoreClass(property.investment_score)}">
        ${getInvestmentLabel(property.investment_score)}
      </div>
    `;
  };

  const getInvestmentScoreClass = (score) => {
    if (score >= 8) return 'hot-investment';
    if (score >= 6) return 'good-investment';
    return 'normal-investment';
  };

  const getInvestmentLabel = (score) => {
    if (score >= 8) return '🔥 Hot Area';
    if (score >= 6) return '📈 Growing';
    return '💡 Potential';
  };

  const getClusterPopup = (cluster) => {
    const points = supercluster.getLeaves(cluster.properties.cluster_id, 10);
    
    return new mapboxgl.Popup({ offset: 25 }).setHTML(`
      <div class="p-4">
        <h3 class="font-bold text-lg mb-2">${cluster.properties.point_count} Properties</h3>
        <div class="space-y-2">
          ${points.map(point => `
            <div class="cursor-pointer hover:bg-gray-50 p-2 rounded" 
                 onclick="window.location.href='/properties/${point.properties.id}'">
              <div class="font-medium">${point.properties.title}</div>
              <div class="text-sm text-gray-600">₦${point.properties.priceNum}M</div>
            </div>
          `).join('')}
        </div>
      </div>
    `);
  };

  const getSinglePropertyPopup = (property) => {
    return new mapboxgl.Popup({ offset: 25 }).setHTML(`
      <div class="p-3 cursor-pointer property-popup" onclick="window.location.href='/properties/${property.id}'">
        <img src="${property.image}" class="w-full h-32 object-cover rounded-lg mb-2" />
        <div class="flex items-center justify-between mb-1">
          <h3 class="font-bold text-gray-900">${property.title}</h3>
          ${property.verified ? '<span class="verified-badge">✓ Verified</span>' : ''}
        </div>
        <p class="text-sm text-gray-600 mb-2">${property.location}</p>
        <div class="flex items-center justify-between">
          <span class="text-xl font-bold">₦${property.priceNum}M</span>
          ${property.growth ? `
            <span class="text-green-600 text-sm">+${property.growth}% /yr</span>
          ` : ''}
        </div>
      </div>
    `);
  };

  return (
    <div className="relative h-screen w-full">
      {/* Main Map Container */}
      <div ref={mapContainer} className="absolute inset-0" />

      {/* Top-right Controls Group */}
      <div className="absolute top-40 right-4 flex flex-col gap-2">
        {/* View List Button */}
        <Link
          to="/properties"
          className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowLeft className="h-6 w-6" />
        </Link>

        {/* Main Controls Button */}
        <div className="relative">
          <button
            onClick={() => setShowControls(!showControls)}
            className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            <SlidersHorizontal className="h-6 w-6" />
          </button>

          {/* Controls Dropdown */}
          {showControls && (
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg py-2">
              {/* Map Styles */}
              <button
                onClick={() => setShowStyleSelector(!showStyleSelector)}
                className="w-full flex items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Layers className="h-4 w-4 mr-3" />
                <span>Map Style</span>
              </button>

              {/* Property Types */}
              <button
                onClick={() => setShowPropertyTypes(!showPropertyTypes)}
                className="w-full flex items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Building className="h-4 w-4 mr-3" />
                <span>Property Types</span>
              </button>

              {/* Toggle Zoom Controls */}
              <button
                onClick={() => setShowZoomControls(!showZoomControls)}
                className="w-full flex items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <ZoomIn className="h-4 w-4 mr-3" />
                <span>Show Zoom Controls</span>
              </button>
            </div>
          )}
        </div>

        {/* Location Button */}
        <button
          onClick={() => {
            setIsLocating(true);
            navigator.geolocation.getCurrentPosition(
              (position) => {
                const { latitude, longitude } = position.coords;
                map.current.flyTo({
                  center: [longitude, latitude],
                  zoom: 15
                });
                setUserLocation([longitude, latitude]);
                setIsLocating(false);
              },
              () => {
                toast.error('Could not get your location');
                setIsLocating(false);
              }
            );
          }}
          className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg hover:bg-gray-50 dark:hover:bg-gray-700"
        >
          {isLocating ? (
            <LoadingSpinner size="sm" />
          ) : (
            <Navigation className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Property Types Modal */}
      <AnimatePresence>
        {showPropertyTypes && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-32 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 w-64"
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Property Types</h3>
              <button
                onClick={() => setShowPropertyTypes(false)}
                className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {propertyTypes.map((type) => (
                <button
                  key={type.id}
                  onClick={() => {
                    setActiveFilter(type.id);
                    setShowPropertyTypes(false);
                  }}
                  className={`flex items-center p-2 rounded-lg transition-colors ${
                    activeFilter === type.id
                      ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                      : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                >
                  <type.icon className="h-4 w-4 mr-2" />
                  <span className="text-sm">{type.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Map Style Selector Modal */}
      <AnimatePresence>
        {showStyleSelector && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-32 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 w-64"
          >
            {mapStyles.map((style) => (
              <button
                key={style.id}
                onClick={() => {
                  setMapStyle(style.id);
                  setShowStyleSelector(false);
                }}
                className={`flex items-center space-x-2 w-full px-4 py-2 rounded-lg transition-colors ${
                  mapStyle === style.id
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <style.icon className="h-5 w-5" />
                <span className="text-sm font-medium">{style.name}</span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Zoom Controls - Only shown when enabled */}
      {showZoomControls && (
        <div className="absolute right-4 top-1/2 -translate-y-1/2 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
          <button
            onClick={() => map.current.zoomIn()}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-t-lg border-b dark:border-gray-700"
          >
            <ZoomIn className="h-5 w-5" />
          </button>
          <button
            onClick={() => map.current.zoomOut()}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-b-lg"
          >
            <ZoomOut className="h-5 w-5" />
          </button>
        </div>
      )}

      {/* Bottom Filters */}
      <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 bg-white dark:bg-gray-800 rounded-full shadow-lg p-2">
        <div className="flex items-center space-x-2">
          {/* Property Type Filter */}
          <select
            value={activeFilter}
            onChange={(e) => setActiveFilter(e.target.value)}
            className="px-4 py-2 rounded-full bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <option value="">All Properties</option>
            {propertyTypes.map((type) => (
              <option key={type.id} value={type.id}>
                {type.label}
              </option>
            ))}
          </select>

          <div className="h-4 w-px bg-gray-300 dark:bg-gray-600" />

          {/* Price Filter */}
          <select
            value={selectedPrice}
            onChange={(e) => setSelectedPrice(e.target.value)}
            className="px-4 py-2 rounded-full bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            {priceRanges.map((range) => (
              <option key={range.id} value={range.id}>
                {range.label}
              </option>
            ))}
          </select>

          <div className="h-4 w-px bg-gray-300 dark:bg-gray-600" />

          {/* Advanced Filters Button */}
          <button
            onClick={() => setShowAdvancedFilters(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <SlidersHorizontal className="h-4 w-4" />
            <span>Advanced Filters</span>
          </button>
        </div>
      </div>

      {/* Search Interface */}
      <div className="top-2 left-0 right-0 z-10 shadow-sm border-b pt-4">
        <div className="container mx-auto">
          <SearchInterface 
            onSearch={({ query, filters }) => {
              // Handle search and filter logic
            }}
            initialFilters={filterValues}
            showTrending={false}
            enhancedView={true}
            variant="compact"
            activeCategory={activeFilter}
            onCategoryChange={setActiveFilter}
            showAIChat={false}
          />
        </div>
      </div>

      {/* Advanced Filters Modal */}
      <AnimatePresence>
        {showAdvancedFilters && (
          <AdvancedFilters
            filters={filterValues}
            setFilters={setFilterValues}
            onClose={() => setShowAdvancedFilters(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default MapView; 

