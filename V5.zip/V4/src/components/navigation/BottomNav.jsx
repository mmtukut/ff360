import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, MapPin, Heart, User } from 'lucide-react';
import { motion } from 'framer-motion';

const BottomNav = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/properties', icon: Search, label: 'Search' },
    { path: '/map', icon: MapPin, label: 'Map' },
    { path: '/saved', icon: Heart, label: 'Saved' },
    { path: '/profile', icon: User, label: 'Profile' }
  ];

  return (
    <div className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 pb-safe z-50 md:hidden">
      <div className="flex items-center justify-around">
        {navItems.map(item => {
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className="relative py-2 px-3 flex flex-col items-center"
            >
              <div className="relative">
                <item.icon 
                  className={`w-6 h-6 ${isActive ? 'text-[#1c5bde]' : 'text-gray-500'}`} 
                />
                {item.label === 'Saved' && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    2
                  </span>
                )}
              </div>
              <span className={`text-xs mt-1 ${isActive ? 'text-[#1c5bde]' : 'text-gray-500'}`}>
                {item.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="bottomNavIndicator"
                  className="absolute -top-1 left-1/2 w-1 h-1 bg-[#1c5bde] rounded-full"
                  initial={false}
                  transition={{
                    type: "spring",
                    stiffness: 500,
                    damping: 30
                  }}
                />
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav; 