import React from "react";
import { Routes, Route, useLocation } from 'react-router-dom';
import { featuredProperties } from './data/properties'; 
import Header from './components/Header';
import AIChatWidget from './components/AIChatWidget';
import Footer from './components/Footer';
import Dashboard from './pages/Dashboard';
import PrivateRoute from './components/PrivateRoute';
import { AuthProvider } from './contexts/AuthContext';
import { SavedPropertiesProvider } from './contexts/SavedPropertiesContext';
import { Toaster } from 'react-hot-toast';

import HomePage from './components/HomePage';
import PropertyDetailView from "./pages/PropertyDetailView";
import Properties from './pages/Properties';
import About from './components/About';
import SignIn from './components/auth/SignIn';
import SignUp from "./components/auth/SignUp";
import MapView from './components/MapView';
import AgentsPage from './pages/Agents/AgentsPage';
import TopAgents from './pages/Agents/TopAgents';
import VerifiedAgents from './pages/Agents/VerifiedAgents';
import AgencyDirectory from './pages/Agents/AgencyDirectory';
import MapLayout from './layouts/MapLayout';
import ForgotPassword from './components/auth/ForgotPassword';
import EmailVerification from './components/auth/EmailVerification';
import CompleteProfile from './components/auth/CompleteProfile';
import AddProperty from './components/property/AddProperty';

function AppContent() {
    const location = useLocation();
    const isMapView = location.pathname === '/map';

    return (
            <div className="app">
                <Toaster position="top-center" />
                {!isMapView && (
                    <>
                        <Header />
                    </>
                )}
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/properties" element={<Properties />} />
                    <Route path="/properties/:id" element={<PropertyDetailView />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/signin" element={<SignIn />} />
                    <Route path="/signup" element={<SignUp />} />
                    <Route path="/forgot-password" element={<ForgotPassword />} />
                    <Route path="/verify-email" element={<EmailVerification />} />
                    <Route 
                        path="/complete-profile" 
                        element={
                            <PrivateRoute>
                                <CompleteProfile />
                            </PrivateRoute>
                        } 
                    />
                    <Route 
                        path="/map" 
                        element={
                            <MapLayout>
                                <MapView 
                                    properties={featuredProperties} 
                                />
                            </MapLayout>
                        } 
                    />
                    <Route path="/agents" element={<AgentsPage />}>
                        <Route index element={<TopAgents />} />
                        <Route path="top" element={<TopAgents />} />
                        <Route path="verified" element={<VerifiedAgents />} />
                        <Route path="agencies" element={<AgencyDirectory />} />
                    </Route>
                    <Route 
                        path="/dashboard" 
                        element={
                            <PrivateRoute>
                                <Dashboard />
                            </PrivateRoute>
                        } 
                    />
                    <Route 
                        path="/add-property" 
                        element={
                            <PrivateRoute>
                                <AddProperty />
                            </PrivateRoute>
                        } 
                    />
                </Routes>
                {!isMapView && <AIChatWidget />}
                {!isMapView && <Footer />}
            </div>
    );
}

function App() {
    return (
        <AuthProvider>
            <SavedPropertiesProvider>
                <AppContent />
            </SavedPropertiesProvider>
        </AuthProvider>
    );
}

export default App;
