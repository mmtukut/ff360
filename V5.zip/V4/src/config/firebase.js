// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";
import { getStorage } from 'firebase/storage';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAm27njF_MtytkDFmqoiXcWFz2rvkYwhnI",
  authDomain: "fastfind360-898f7.firebaseapp.com",
  projectId: "fastfind360-898f7",
  storageBucket: "fastfind360-898f7.firebasestorage.app",
  messagingSenderId: "305526454305",
  appId: "1:305526454305:web:5b6453ee158f4324994b60",
  measurementId: "G-R3LQ42G4X5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Export the auth and db instances
export const auth = getAuth(app);
export const db = getFirestore(app);

// Initialize Google Auth Provider
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export const storage = getStorage(app);

export default app;