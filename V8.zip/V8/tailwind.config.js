/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  theme: {
      extend: {
          screens: {
              'xs': '480px',
              '3xl': '1920px',
          },
          colors: {
              brand: {
                  DEFAULT: '#0e109f',
                  light: '#0e109f/10',
                  dark: '#0c0d8a',
              },
          },
      },
  },
  plugins: [],
};