const properties = [
  // Properties from the frontend
  {
    id: 1,
    ownerId: 'owner1',
    title: "Luxury Villa in Asokoro",
    price: 120000000,
    location: "Asokoro District, Abuja",
    bedrooms: 5,
    bathrooms: 4,
    area: "300m²",
    image: "/images/image1.jpg",
    images: ["/images/image1.jpg"],
    description: "Elegant villa with premium finishes in prestigious Asokoro.",
    coordinates: [7.526, 9.045],
    type: "luxury",
    amenities: ["Swimming Pool", "24/7 Security", "Garden", "Garage"],
    status: "Available",
    dateAvailable: "2025-02-06"
  },
  {
    id: 2,
    ownerId: 'owner1',
    title: "Modern 3 Bedroom Apartment",
    location: "Gombe",
    price: 5000000,
    type: "Apartment",
    bedrooms: 3,
    bathrooms: 2,
    area: "180m²",
    image: "/images/image2.jpg",
    images: ["/images/image2.jpg"],
    amenities: ["Swimming Pool", "24/7 Security", "Parking Space"],
    description: "Beautiful modern apartment in a serene environment",
    status: "Available",
    coordinates: [11.169, 10.287],
  
  },
  {
    id: 3,
    ownerId: 'owner1',
    title: "Luxury Villa with Garden",
    location: "Gombe GRA",
    price: 12000000,
    type: "Villa",
    bedrooms: 5,
    bathrooms: 4,
    amenities: ["Garden", "Security", "Garage", "Swimming Pool"],
    description: "Spacious luxury villa with beautiful garden",
    status: "Available",
    image: "/images/image3.jpg",
    images: ["/images/image3.jpg"],
    coordinates: [11.172, 10.290],

  },
  {
    id: 4,
    ownerId: 'owner1',
    title: "Office Space in Central Business District",
    price: 45000000,
    location: "CBD, Abuja",
    bedrooms: null,
    bathrooms: 2,
    area: "200m²",
    image: "/images/image3.jpg",
    images: ["/images/image3.jpg"],
    description: "Prime office space in Abuja's business hub.",
    coordinates: [7.498, 9.027],
    type: "commercial",
    amenities: ["24/7 Power", "Parking Lot", "Security"],
    status: "Available",

  },
  {
    id: 5,
    ownerId: 'owner1',
    title: "Student Apartment",
    location: "Near Gombe University",
    price: 2000000,
    type: "Apartment",
    bedrooms: 1,
    bathrooms: 1,
    area: "80m²",
    amenities: ["Internet", "Security", "Study Area"],
    description: "Perfect for students, close to university",
    status: "Available",
    image: "/images/image1.jpg",
    images: ["/images/image1.jpg"],
    coordinates: [11.165, 10.285],
  },
  {
    id: 6,
    ownerId: 'owner1',
    title: "Garden Apartment in Wuse",
    price: 65000000,
    location: "Wuse Zone 6, Abuja",
    bedrooms: 2,
    bathrooms: 2,
    area: "120m²",
    image: "/images/image2.jpg",
    images: ["/images/image2.jpg"],
    description: "Modern apartment with beautiful garden views.",
    coordinates: [7.459, 9.072],
    type: "residential",
    amenities: ["Garden", "Security", "Parking"],
    status: "Available",
  },
  // ... continue with other properties
];

const getPropertyById = (id) => properties.find(p => p.id === id);

const filterProperties = (filters) => {
  return properties.filter(property => {
    let matches = true;
    if (filters.location) {
      matches = matches && property.location.toLowerCase().includes(filters.location.toLowerCase());
    }
    if (filters.maxPrice) {
      matches = matches && property.price <= filters.maxPrice;
    }
    if (filters.type) {
      matches = matches && property.type === filters.type;
    }
    if (filters.bedrooms) {
      matches = matches && property.bedrooms >= filters.bedrooms;
    }
    if (filters.amenities) {
      matches = matches && filters.amenities.every(amenity => 
        property.amenities.includes(amenity)
      );
    }
    return matches;
  });
};

// Additional helper functions
const getPropertiesByType = (type) => properties.filter(p => p.type === type);
const getPropertiesByPriceRange = (min, max) => properties.filter(p => p.price >= min && p.price <= max);
const getPropertiesByLocation = (location) => properties.filter(p => p.location.toLowerCase().includes(location.toLowerCase()));

module.exports = {
  properties,
  getPropertyById,
  filterProperties,
  getPropertiesByType,
  getPropertiesByPriceRange,
  getPropertiesByLocation
}; 