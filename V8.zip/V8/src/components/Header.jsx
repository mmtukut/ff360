import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, Search, Bell, User, 
  Building, Calculator, Heart, 
  MessageSquare, Settings, LogOut,
  Home, DollarSign, Map, Briefcase,
  ChevronDown, Globe, Sun, Moon,
  Building2, Crown, TrendingUp, Calendar,
  MapPin, Phone, Users, Star, Plus,
  ArrowRight, Sparkles
} from 'lucide-react';
import Logo from '../assets/images/logo.png';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { LoadingSpinner } from './common/LoadingSpinner';
import { useSwipeable } from 'react-swipeable';

const Header = ({ properties }) => {
  const location = useLocation();
  const { currentUser } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState(null);
  const [hoveredMenu, setHoveredMenu] = useState(null);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef(null);
  const [savedCount, setSavedCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [propertiesSubmenuOpen, setPropertiesSubmenuOpen] = useState(false);
  const [agentsSubmenuOpen, setAgentsSubmenuOpen] = useState(false);
  const mobileMenuRef = useRef(null);

  // Enhanced navigation with categories
  const mainNavLinks = [
    {
      name: 'Home',
      path: '/',
      icon: Home,
    },
 
    {
      name: 'Properties',
      path: '/properties',
      icon: Building,
      submenu: [
        { name: 'Buy', path: '/properties', icon: Home },
        { name: 'Rent', path: '/properties', icon: Building2 },
        { name: 'Shortlets', path: '/properties', icon: Calendar },
        { name: 'Commercial', path: '/properties', icon: Briefcase }
      ]
    },
    {
      name: 'Find Agents',
      path: '/agents',
      icon: Users,
      submenu: [
        { name: 'Top Agents', path: '/agents/top', icon: Star },
        { name: 'Verified Agents', path: '/agents/verified', icon: Users },
        { name: 'Agency Directory', path: '/agents/agencies', icon: Briefcase }
      ]
    }
  ];

  // Scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const fetchSavedCount = async () => {
      if (!currentUser) return;
      
      try {
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        const savedProperties = userDoc.data()?.savedProperties || [];
        setSavedCount(savedProperties.length);
      } catch (error) {
        console.error('Error fetching saved count:', error);
      }
    };

    fetchSavedCount();
  }, [currentUser]);

  const handleSubmenuToggle = (index) => {
    setActiveSubmenu(activeSubmenu === index ? null : index);
  };

  // Update the Right Section with enhanced profile/auth buttons
  const ProfileSection = () => {
    if (!isAuthenticated) {
      return
  
    }

    return (
      <div className="relative">
        <button 
          onClick={() => setIsProfileOpen(!isProfileOpen)}
          className="flex items-center gap-2 px-3 py-2 hover:bg-[#1c5bde]/5 rounded-full transition-colors"
        >
          <div className="relative">
            <img 
              src="https://ui-avatars.com/api/?name=John+Doe&background=1c5bde&color=fff" 
              alt="Profile" 
              className="w-8 h-8 rounded-full border-2 border-[#1c5bde]"
            />
            <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"></div>
          </div>
          <span className="hidden md:block text-sm font-medium text-gray-700">John Doe</span>
          <ChevronDown className="h-4 w-4 text-gray-500" />
        </button>

        <AnimatePresence>
          {isProfileOpen && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border py-2"
            >
              <div className="px-4 py-3 border-b">
                <div className="flex items-center gap-3">
                  <img 
                    src="https://ui-avatars.com/api/?name=John+Doe&background=1c5bde&color=fff" 
                    alt="Profile" 
                    className="w-12 h-12 rounded-full border-2 border-[#1c5bde]"
                  />
                  <div>
                    <p className="font-medium text-gray-900">John Doe</p>
                    <p className="text-sm text-gray-500">john@example.com</p>
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <span className="px-2 py-1 bg-[#1c5bde]/10 text-[#1c5bde] text-xs rounded-full">
                    Premium Member
                  </span>
                  <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                    Verified Agent
                  </span>
                </div>
              </div>

              <div className="py-2">
                <div className="px-4 py-2">
                  <p className="text-xs font-medium text-gray-500 uppercase">Account</p>
                </div>
                <Link to="/profile" className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-[#1c5bde]/5">
                  <User className="h-4 w-4 text-[#1c5bde]" />
                  <div>
                    <p className="text-sm font-medium">Profile</p>
                    <p className="text-xs text-gray-500">Manage your account</p>
                  </div>
                </Link>
                <Link to="/favorites" className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-[#1c5bde]/5">
                  <Heart className="h-4 w-4 text-[#1c5bde]" />
                  <div>
                    <p className="text-sm font-medium">Favorites</p>
                    <p className="text-xs text-gray-500">Saved properties</p>
                  </div>
                </Link>
                <Link to="/messages" className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-[#1c5bde]/5">
                  <MessageSquare className="h-4 w-4 text-[#1c5bde]" />
                  <div>
                    <p className="text-sm font-medium">Messages</p>
                    <p className="text-xs text-gray-500">View your conversations</p>
                  </div>
                </Link>
              </div>

              <div className="py-2 border-t">
                <div className="px-4 py-2">
                  <p className="text-xs font-medium text-gray-500 uppercase">Settings</p>
                </div>
                <Link to="/settings" className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-[#1c5bde]/5">
                  <Settings className="h-4 w-4 text-[#1c5bde]" />
                  <div>
                    <p className="text-sm font-medium">Settings</p>
                    <p className="text-xs text-gray-500">Preferences & security</p>
                  </div>
                </Link>
                <button 
                  onClick={() => {/* Add logout logic */}}
                  className="flex items-center gap-3 px-4 py-2 text-red-600 hover:bg-red-50 w-full"
                >
                  <LogOut className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">Sign Out</p>
                    <p className="text-xs text-red-500">End your session</p>
                  </div>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  // Handle hover persistence
  const handleMouseEnter = (index) => {
    setHoveredMenu(index);
  };

  const handleMouseLeave = (event) => {
    const related = event.relatedTarget;
    if (!dropdownRef.current?.contains(related)) {
      setHoveredMenu(null);
    }
  };

  // Function to toggle mobile menu
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Function to toggle properties submenu
  const togglePropertiesSubmenu = () => {
    setPropertiesSubmenuOpen(!propertiesSubmenuOpen);
  };

  // Function to toggle agents submenu
  const toggleAgentsSubmenu = () => {
    setAgentsSubmenuOpen(!agentsSubmenuOpen);
  };

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target)) {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Swipe handlers for closing the mobile menu
  const swipeHandlers = useSwipeable({
    onSwipedRight: () => {
      if (isMobileMenuOpen) {
        setIsMobileMenuOpen(false);
      }
    },
    preventDefaultTouchmoveEvent: true,
    trackMouse: true
  });

  return (
    <header 
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg shadow-sm' 
          : 'bg-white dark:bg-gray-800'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-[72px]">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <img src={Logo} alt="FastFind" className="h-8" />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {mainNavLinks.map((link) => (
              <div key={link.name} className="relative group">
                <Link
                  to={link.path}
                  className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-[#1c5bde] dark:hover:text-blue-400"
                >
                  <link.icon className="w-4 h-4" />
                  <span>{link.name}</span>
                  {link.submenu && (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </Link>
                {link.submenu && (
                  <div className="absolute top-full left-0 w-64 p-3 bg-white rounded-xl shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                    <div className="space-y-2">
                      {link.submenu.map((item) => (
                        <Link
                          key={item.name}
                          to={item.path}
                          className="flex items-center gap-2 p-2 text-gray-600 hover:text-[#1c5bde] rounded-lg hover:bg-gray-50"
                        >
                          <item.icon className="w-4 h-4" />
                          <span>{item.name}</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Quick Actions */}
          <div className="flex items-center gap-3">

            {/* Map View Button - Now visible on both mobile and desktop */}
            <Link 
              to="/map"
              state={{ properties }}
              className="flex items-center gap-2 px-3 py-2 bg-[#1c5bde]/10 text-[#1c5bde] rounded-full hover:bg-[#1c5bde]/20 transition-colors"
            >
              <Map className="w-5 h-5" />
              <span className="hidden md:inline text-sm">Map View</span>
            </Link>

            {/* Saved Properties - Moved to header, visible on both mobile and desktop */}
            <Link 
              to="/dashboard?tab=saved"
              className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
            >
              <div className="relative">
                <Heart className="w-5 h-5" />
                {savedCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {savedCount}
                  </span>
                )}
              </div>
              <span className="hidden md:inline text-sm">Saved</span>
            </Link>

            {/* Add Property Button */}
            {currentUser && (
              <Link
                to="/add-property"
                className="hidden md:flex items-center px-4 py-2 bg-[#1c5bde] dark:bg-blue-600 text-white rounded-full hover:bg-[#1c5bde]/90 dark:hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                List Property
              </Link>
            )}

            {/* User Profile/Login - Desktop only */}
            <button className="hidden md:flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-full hover:border-gray-300 transition-colors">
            <Link 
              to="/signin" 
              className="hidden md:flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-full hover:border-gray-300 transition-colors"
            >
              <User className="w-4 h-4 text-gray-600" />
              <span className="text-gray-600">Sign in</span>
            </Link>
              <Link
              to="/signup"
              className="bg-[#1c5bde] hover:bg-[#0c0d8a] text-white px-6 py-2 rounded-full text-sm font-medium transition-colors shadow-sm hover:shadow-md"
            >
              Sign Up
            </Link>
            </button>

            {/* Profile Section */}
            <ProfileSection />

            {/* Mobile Menu Button */}
            <button 
              className="lg:hidden p-2 hover:bg-gray-100 rounded-full transition-colors"
              onClick={toggleMobileMenu}
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6 text-gray-600" />
              ) : (
                <Menu className="h-6 w-6 text-gray-600" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <AnimatePresence>
          {showSearch && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-gray-100 py-4"
            >
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search properties, locations..."
                  className="w-full px-4 py-2 pl-10 bg-gray-50 rounded-full focus:outline-none focus:ring-2 focus:ring-[#1c5bde]/20"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Menu - Right Side */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={toggleMobileMenu}
                className="fixed inset-0 bg-black/20 z-50 md:hidden"
              />

              {/* Menu Panel */}
              <motion.div
                ref={mobileMenuRef}
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                className="fixed top-0 right-0 h-full w-72 bg-white shadow-2xl z-50 overflow-y-auto"
                {...swipeHandlers}
              >
                <div className="flex flex-col h-full">
                  {/* Mobile Menu Header */}
                  <div className="p-4 border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <Link to="/" className="flex items-center gap-2 font-bold text-xl text-[#1c5bde]">
                        <img src={Logo} alt="FastFind" className="w-6 h-6" />
                        FastFind360
                      </Link>
                      <button onClick={toggleMobileMenu} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <X className="w-6 h-6" />
                      </button>
                    </div>
                  </div>

                  {/* Mobile Menu Links */}
                  <nav className="flex flex-col p-4 space-y-2">
                    {/* Main Navigation */}
                    <Link
                      to="/"
                      onClick={toggleMobileMenu}
                      className={`flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors ${
                        location.pathname === '/' ? 'bg-gray-100 text-[#1c5bde]' : ''
                      }`}
                    >
                      <Home className="w-5 h-5" />
                      Home
                    </Link>

                    {/* Properties Submenu */}
                    <div className="flex flex-col">
                      <button
                        onClick={togglePropertiesSubmenu}
                        className="flex items-center justify-between p-3 hover:bg-gray-100 rounded-lg transition-colors w-full text-left"
                      >
                        <div className="flex items-center gap-3">
                          <Building className="w-5 h-5" />
                          Properties
                        </div>
                        <ArrowRight className={`w-4 h-4 text-gray-500 transition-transform ${propertiesSubmenuOpen ? 'rotate-90' : ''}`} />
                      </button>
                      {propertiesSubmenuOpen && (
                        <div className="ml-6 space-y-1">
                          <Link
                            to="/properties"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Building2 className="w-4 h-4" />
                            Buy
                          </Link>
                          <Link
                            to="/properties"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Calendar className="w-4 h-4" />
                            Rent
                          </Link>
                          <Link
                            to="/properties"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Briefcase className="w-4 h-4" />
                            Shortlets
                          </Link>
                          <Link
                            to="/properties"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Briefcase className="w-4 h-4" />
                            Commercial
                          </Link>
                        </div>
                      )}
                    </div>

                    {/* Agents Submenu */}
                    <div className="flex flex-col">
                      <button
                        onClick={toggleAgentsSubmenu}
                        className="flex items-center justify-between p-3 hover:bg-gray-100 rounded-lg transition-colors w-full text-left"
                      >
                        <div className="flex items-center gap-3">
                          <Users className="w-5 h-5" />
                          Find Agents
                        </div>
                        <ArrowRight className={`w-4 h-4 text-gray-500 transition-transform ${agentsSubmenuOpen ? 'rotate-90' : ''}`} />
                      </button>
                      {agentsSubmenuOpen && (
                        <div className="ml-6 space-y-1">
                          <Link
                            to="/agents/top"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Star className="w-4 h-4" />
                            Top Agents
                          </Link>
                          <Link
                            to="/agents/verified"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Users className="w-4 h-4" />
                            Verified Agents
                          </Link>
                          <Link
                            to="/agents/agencies"
                            onClick={toggleMobileMenu}
                            className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <Briefcase className="w-4 h-4" />
                            Agency Directory
                          </Link>
                        </div>
                      )}
                    </div>

                    {/* Dashboard Links */}
                    {currentUser && (
                      <>
                        <Link
                          to="/dashboard?tab=saved"
                          onClick={toggleMobileMenu}
                          className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <Heart className="w-5 h-5" />
                          Saved Properties
                        </Link>
                        <Link
                          to="/add-property"
                          onClick={toggleMobileMenu}
                          className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <Plus className="w-5 h-5" />
                          List Property
                        </Link>
                      </>
                    )}
                  </nav>

                  {/* Mobile Menu Footer */}
                  <div className="mt-auto p-4 border-t border-gray-100">
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4" />
                      <span className="text-sm">Account</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600 mt-2">
                      <Phone className="w-4 h-4" />
                      <span className="text-sm">Contact Us</span>
                    </div>
                    {currentUser && (
                      <div className="flex items-center gap-2 text-gray-600 mt-2">
                        <Link to="/profile" className="flex items-center gap-2 text-gray-600">
                          <User className="w-4 h-4" />
                          <span className="text-sm">Profile</span>
                        </Link>
                      </div>
                    )}
                    {currentUser && (
                      <div className="flex items-center gap-2 text-gray-600 mt-2">
                        <Link to="/messages" className="flex items-center gap-2 text-gray-600">
                          <MessageSquare className="w-4 h-4" />
                          <span className="text-sm">Messages</span>
                        </Link>
                      </div>
                    )}
                    {currentUser && (
                      <div className="flex items-center gap-2 text-gray-600 mt-2">
                        <Link to="/settings" className="flex items-center gap-2 text-gray-600">
                          <Settings className="w-4 h-4" />
                          <span className="text-sm">Settings</span>
                        </Link>
                      </div>
                    )}
                    {currentUser && (
                      <button 
                        onClick={() => {/* Add logout logic */}}
                        className="flex items-center gap-2 text-red-600 mt-2 w-full text-left"
                      >
                        <LogOut className="w-4 h-4" />
                        <span className="text-sm">Sign Out</span>
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};

export default Header; 