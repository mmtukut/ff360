import React, { useEffect, useState } from 'react';
import { Bookmark, User, Bed, Bath, Square, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import { getDoc, doc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Link } from 'react-router-dom';
import { Dialog } from '@headlessui/react';
import OwnerProfileModal from './OwnerProfileModal';
import { getOwnerById } from '../data/owners.data'; // Import the function

const PropertyCard = ({ property, onSaveChange }) => {
  const { currentUser, saveProperty, removeSavedProperty } = useAuth();
  const [isSaved, setIsSaved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showOwnerModal, setShowOwnerModal] = useState(false);
  const [ownerDetails, setOwnerDetails] = useState(null);

  // Check if property is saved when component mounts
  useEffect(() => {
    const checkIfSaved = async () => {
      if (!currentUser) return;
      
      try {
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        const savedProperties = userDoc.data()?.savedProperties || [];
        setIsSaved(savedProperties.includes(property.id));
      } catch (error) {
        console.error('Error checking saved status:', error);
      }
    };

    checkIfSaved();
  }, [currentUser, property.id]);

  // Fetch owner details when modal is opened
  const fetchOwnerDetails = async (ownerId) => {
    console.log('Fetching owner details for:', ownerId);
    try {
      const ownerData = getOwnerById(ownerId);
      if (!ownerData) {
        console.error('Owner document does not exist');
        toast.error('Owner information not found');
        return;
      }
      console.log('Owner details fetched:', ownerData);
      setOwnerDetails(ownerData);
      
      // Update the property's owner information
      property.owner = ownerData;
    } catch (error) {
      console.error('Error fetching owner details:', error);
      toast.error('Could not load owner details');
    }
  };

  const handleOwnerClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('Opening modal for owner:', property.ownerId);
    if (property.ownerId) {
      fetchOwnerDetails(property.ownerId);
      setShowOwnerModal(true);
    }
  };

  const handleSaveProperty = async (e) => {
    e.stopPropagation(); // Prevent card click event

    if (!currentUser) {
      toast.error('Please login to save properties');
      return;
    }

    setIsLoading(true);
    try {
      if (isSaved) {
        await removeSavedProperty(property.id);
        setIsSaved(false);
        toast.success('Property removed from saved list');
      } else {
        await saveProperty(property.id);
        setIsSaved(true);
        toast.success('Property saved successfully');
      }
      
      // Trigger a refresh of the saved count
      if (onSaveChange) {
        onSaveChange();
      }
      
    } catch (error) {
      console.error('Error saving property:', error);
      toast.error('Failed to save property');
    } finally {
      setIsLoading(false);
    }
  };

  // Placeholder for viewAllReviews function
  const viewAllReviews = (propertyId) => {
    // Implement the logic to view all reviews for the property
    console.log(`Viewing all reviews for property ID: ${propertyId}`);
  };

  return (
    <>
      <Link to={`/property/${property.id}`}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="group cursor-pointer bg-white rounded-xl overflow-hidden flex flex-col h-full hover:shadow-md transition-all duration-300"
        >
          {/* Image Section */}
          <div className="relative aspect-[4/3]">
            <img
              src={property.images?.[0] || '/images/placeholder.jpg'}
              alt={property.title}
              className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
              onError={(e) => { e.target.src = '/images/placeholder.jpg'; }}
            />
            
            {/* Property Type Label */}
            <div className="absolute top-4 left-4">
              <span className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-gray-900">
                {property.type}
              </span>
            </div>

            {/* Owner Profile Button with Album Style */}
            <button
              onClick={handleOwnerClick}
              className="absolute bottom-4 left-4 flex items-center gap-2 bg-white/90 backdrop-blur-sm p-1.5 rounded-full shadow-lg transition-all duration-300 hover:bg-white"
            >
              <div className="relative w-10 h-10 rounded-full overflow-hidden border-4 border-white shadow-md">
                <img
                  src={property.owner?.avatar || '/images/agents/default-avatar.jpg'}
                  alt="Property Owner"
                  className="w-full h-full object-cover"
                  onError={(e) => { e.target.src = '/images/agents/default-avatar.jpg'; }}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 opacity-30 rounded-full"></div>
              </div>
              <span className="font-medium text-gray-900">
                {property.owner?.name || 'Owner'}
              </span>
            </button>

            {/* Save Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.preventDefault();
                handleSaveProperty(e);
              }}
              className="absolute top-4 right-4 p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-sm hover:shadow-md"
            >
              <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-blue-500 text-blue-500' : 'text-gray-600'}`} />
            </motion.button>
          </div>

          {/* Content Section */}
          <div className="p-4 flex flex-col h-full">
            {/* Title & Location */}
            <div className="mb-1">
              <h3 className="text-lg font-semibold text-gray-900">{property.title}</h3>
              <p className="text-sm text-gray-600">{property.location}</p>
            </div>

            {/* Property Stats */}
            <div className="grid grid-cols-3 gap-1 py-1 border-y border-gray-100">
              <div className="text-center">
                <span className="font-semibold">{property.bedrooms}</span>
                <p className="text-xs text-gray-500">Beds</p>
              </div>
              <div className="text-center">
                <span className="font-semibold">{property.bathrooms}</span>
                <p className="text-xs text-gray-500">Baths</p>
              </div>
              <div className="text-center">
                <span className="font-semibold">{property.area}</span>
                <p className="text-xs text-gray-500">Area</p>
              </div>
            </div>

            {/* Price and Actions */}
            <div className="mt-auto pt-1 flex items-center justify-between">
              <div className="flex flex-col">
                <p className="font-semibold text-blue-600">₦{property.price.toLocaleString()}</p>
                <span className={`text-xs ${
                  property.availability === 'Available' 
                    ? 'text-green-700'
                    : 'text-red-700'
                }`}>
                  {property.availability}
                </span>
              </div>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  window.handlePropertyChat(property.id, property.title);
                }}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium bg-blue-50 px-2 py-1 rounded-full hover:bg-blue-100 transition-colors"
              >
                Chat about Property
              </button>
            </div>
          </div>
        </motion.div>
      </Link>

      {/* Owner Profile Modal */}
      <OwnerProfileModal
        isOpen={showOwnerModal}
        onClose={() => setShowOwnerModal(false)}
        ownerDetails={ownerDetails}
      />
    </>
  );
};

export default PropertyCard;