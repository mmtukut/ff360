import { useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';

const AMENITY_TYPES = {
  restaurant: { icon: '🍽️', color: '#FF5A5F' },
  school: { icon: '🎓', color: '#00A699' },
  park: { icon: '🌳', color: '#484848' },
  transport: { icon: '🚇', color: '#767676' },
  shopping: { icon: '🛍️', color: '#008489' },
};

const NearbyAmenities = ({ map, property }) => {
  const [amenities, setAmenities] = useState([]);

  useEffect(() => {
    if (!map || !property) return;

    // Clear existing amenity markers
    amenities.forEach(marker => marker.remove());
    setAmenities([]);

    // Fetch nearby amenities using Mapbox Places API
    const fetchAmenities = async () => {
      const newAmenities = [];
      
      for (const [type, style] of Object.entries(AMENITY_TYPES)) {
        const response = await fetch(
          `https://api.mapbox.com/geocoding/v5/mapbox.places/${type}.json?` +
          `proximity=${property.longitude},${property.latitude}&` +
          `access_token=${mapboxgl.accessToken}&` +
          `limit=5`
        );
        
        const data = await response.json();
        
        data.features.forEach(feature => {
          // Create custom marker element
          const el = document.createElement('div');
          el.className = 'amenity-marker';
          el.innerHTML = `
            <div class="relative group">
              <div class="w-8 h-8 rounded-full flex items-center justify-center text-white"
                   style="background-color: ${style.color}">
                ${style.icon}
              </div>
              <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block">
                <div class="bg-white px-2 py-1 rounded shadow-lg text-sm whitespace-nowrap">
                  ${feature.text}
                </div>
              </div>
            </div>
          `;

          // Add marker to map
          const marker = new mapboxgl.Marker(el)
            .setLngLat(feature.center)
            .addTo(map);

          newAmenities.push(marker);
        });
      }

      setAmenities(newAmenities);
    };

    fetchAmenities();

    return () => {
      amenities.forEach(marker => marker.remove());
    };
  }, [map, property]);

  return null; // This is a utility component, no UI needed
};

export default NearbyAmenities; 