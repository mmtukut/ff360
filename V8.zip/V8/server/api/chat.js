const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require("@google/generative-ai");
const { properties, getPropertyById, filterProperties } = require('../../src/data/properties.data');
const nlpUtils = require('../utils/nlpUtils');
const chatModel = require('../models/chatModel');

// Access your API key as an environment variable
const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
    console.error("GEMINI_API_KEY is not set in environment variables");
    throw new Error("Missing GEMINI_API_KEY");
}

console.log("Initializing Gemini API with key length:", apiKey.length);
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: "gemini-pro"});

// Initialize the chat model
chatModel.buildModel();

// Helper function to format property details in Markdown
const formatPropertyMarkdown = (property) => {
  return `
**[${property.title}]**
- **Location:** ${property.location}
- **Price:** ₦${property.price.toLocaleString()}
- **Type:** ${property.type}
- **Bedrooms:** ${property.bedrooms}
- **Bathrooms:** ${property.bathrooms}
- **Amenities:** ${property.amenities.join(', ')}
- **Status:** ${property.status}
- [View Details](/properties/${property.id})
- [Chat about this property](/chat?propertyId=${property.id})
`;
};

router.post('/chat', async (req, res) => {
  try {
    console.log("Received chat request:", {
        messageLength: req.body.message?.length,
        userId: req.body.userId,
        propertyId: req.body.propertyId
    });

    const { message, userId = 'default-user', propertyId } = req.body;

    if (!message) {
      console.error("Error: Message is missing in the request body");
      return res.status(400).json({ error: "Message is required" });
    }

    // Step 1: Analyze the message using our NLP utilities
    console.log("Starting NLP analysis...");
    const nlpAnalysis = nlpUtils.generateContextAwareResponse(userId, message);
    console.log("NLP Analysis completed:", {
        sentiment: nlpAnalysis.sentiment,
        entitiesCount: nlpAnalysis.entities.length
    });

    // Step 2: Get intent prediction from our model
    console.log("Starting intent prediction...");
    const intentPrediction = await chatModel.predict(message);
    console.log("Intent prediction completed:", intentPrediction);

    // Step 3: Filter properties based on entities and propertyId
    let relevantProperties = [];
    if (propertyId) {
      // If propertyId is provided, only include that specific property
      const property = properties.find(p => p.id.toString() === propertyId);
      if (property) {
        relevantProperties = [property];
      }
    } else {
      // Filter based on entities
      const filters = {
        location: nlpAnalysis.entities.find(e => e.type === 'location')?.text,
        maxPrice: nlpAnalysis.entities.find(e => e.type === 'price')?.text,
        date: nlpAnalysis.entities.find(e => e.type === 'date')?.text
      };

      relevantProperties = properties;
      if (filters.location) {
        relevantProperties = relevantProperties.filter(p => 
          p.location.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      if (filters.maxPrice) {
        const maxPrice = parseInt(filters.maxPrice.replace(/[₦MK,]/g, '')) * 1000000;
        relevantProperties = relevantProperties.filter(p => p.price <= maxPrice);
      }
    }

    // Step 4: Create an enhanced prompt for Gemini
    const enhancedPrompt = `
You are FastFind AI, a friendly and knowledgeable real estate assistant. Your role is to engage in natural conversations while providing detailed property information.

Key Personality Traits:
- Friendly and conversational
- Proactive in offering additional relevant information
- Asks follow-up questions to better understand user needs
- Provides detailed explanations and insights
- Maintains context throughout the conversation

Context:
${JSON.stringify(nlpAnalysis.context)}

User Sentiment: ${nlpAnalysis.sentiment.sentiment}
Detected Entities: ${JSON.stringify(nlpAnalysis.entities)}
Intent: ${intentPrediction.intent}

${propertyId ? 'Specific Property:' : 'Available Properties:'}
${relevantProperties.map(formatPropertyMarkdown).join('\n')}

Instructions:
1. Respond conversationally, as if having a real chat
2. Provide detailed property insights beyond basic facts
3. Include relevant market insights when appropriate
4. Ask follow-up questions to better understand user needs
5. Suggest related properties or features they might be interested in
6. Use natural language transitions between topics
7. Format prices with the ₦ symbol and proper formatting
8. End responses with an engaging question or suggestion for further exploration

Remember to:
- Explain why certain features might be beneficial
- Share relevant neighborhood insights
- Compare with similar properties when relevant
- Suggest additional features they might be interested in
- Keep the conversation flowing naturally

User Query: ${message}
Assistant: Let me help you with that...`;

    console.log("Sending request to Gemini API...");
    let aiResponse = "";
    try {
      const result = await model.generateContent(enhancedPrompt);
      const response = await result.response;
      aiResponse = response.text();
      console.log("Received response from Gemini API");
    } catch (geminiError) {
      console.error("Gemini API error:", {
          error: geminiError.message,
          stack: geminiError.stack
      });
      
      // Create a fallback response using filtered properties
      if (relevantProperties.length > 0) {
        aiResponse = `I found ${relevantProperties.length} properties that might interest you:\n\n` +
          relevantProperties.map(p => formatPropertyMarkdown(p)).join('\n');
      } else {
        aiResponse = "I apologize, but I couldn't find any properties matching your criteria. Would you like to broaden your search or look for different features?";
      }
    }

    // Update context with AI's response
    nlpUtils.updateContext(userId, {
      role: 'assistant',
      content: aiResponse
    });

    // Send response to client
    res.json({
      message: aiResponse,
      analysis: {
        sentiment: nlpAnalysis.sentiment,
        entities: nlpAnalysis.entities,
        intent: intentPrediction
      },
      properties: relevantProperties
    });

  } catch (error) {
    console.error("Chat API error:", {
      error: error.message,
      stack: error.stack,
      body: req.body
    });
    res.status(500).json({ 
      error: "Error processing chat request",
      details: error.message
    });
  }
});

// Get all properties
router.get('/properties', (req, res) => {
  res.json(properties);
});

// Get specific property
router.get('/properties/:id', (req, res) => {
  const property = properties.find(p => p.id.toString() === req.params.id);
  if (property) {
    res.json(property);
  } else {
    res.status(404).json({ error: "Property not found" });
  }
});

// Test endpoint
router.get('/test', (req, res) => {
  res.json({ message: 'API is working' });
});

module.exports = router;