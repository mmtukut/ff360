// This file handles sentiment analysis, entity recognition, and context management

class NLPUtils {
    constructor() {
        this.conversations = new Map();
        this.maxContextLength = 5;
        this.defaultResponse = "I'm still learning. Could you please rephrase that?";
    }

    // Sentiment Analysis
    analyzeSentiment(text) {
        // Simple rule-based sentiment analysis
        const positiveWords = ['good', 'great', 'awesome', 'excellent', 'happy', 'love'];
        const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'sad', 'hate'];
        
        const words = text.toLowerCase().split(' ');
        let score = 0;
        
        words.forEach(word => {
            if (positiveWords.includes(word)) score++;
            if (negativeWords.includes(word)) score--;
        });
        
        return {
            score,
            sentiment: score > 0 ? 'positive' : score < 0 ? 'negative' : 'neutral'
        };
    }

    // Entity Recognition
    extractEntities(text) {
        const entities = [];

        // Simple pattern matching for dates (MM/DD/YYYY or MM-DD-YYYY)
        const datePattern = /\b\d{1,2}[-/]\d{1,2}[-/]\d{4}\b/g;
        const dates = text.match(datePattern) || [];
        dates.forEach(date => {
            entities.push({ type: 'date', text: date });
        });

        // Simple pattern matching for numbers
        const numberPattern = /\b\d+\b/g;
        const numbers = text.match(numberPattern) || [];
        numbers.forEach(number => {
            entities.push({ type: 'number', text: number });
        });

        // Simple pattern matching for locations (words after "in", "at", "near")
        const locationPattern = /\b(?:in|at|near)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g;
        let match;
        while ((match = locationPattern.exec(text)) !== null) {
            entities.push({ type: 'location', text: match[1] });
        }

        // Simple pattern matching for prices (₦ followed by numbers)
        const pricePattern = /₦\s*\d+(?:,\d{3})*(?:\.\d{2})?(?:\s*[Mm]illion|\s*[Kk])?/g;
        const prices = text.match(pricePattern) || [];
        prices.forEach(price => {
            entities.push({ type: 'price', text: price });
        });

        return entities;
    }

    // Context Management
    updateContext(userId, message) {
        if (!this.conversations.has(userId)) {
            this.conversations.set(userId, []);
        }

        const context = this.conversations.get(userId);
        context.push({
            message,
            timestamp: new Date().toISOString()
        });

        // Keep only the last N messages
        if (context.length > this.maxContextLength) {
            context.shift();
        }

        return context;
    }

    getContext(userId) {
        return this.conversations.get(userId) || [];
    }

    // Enhanced response generation based on context
    generateContextAwareResponse(userId, currentMessage) {
        try {
            const context = this.getContext(userId);
            const sentiment = this.analyzeSentiment(currentMessage) || {score: 0, sentiment: 'neutral'};
            const entities = this.extractEntities(currentMessage) || [];
            
            return {
                context: context,
                sentiment: sentiment,
                entities: entities,
                suggestedResponse: this.generateSuggestedResponse(sentiment.sentiment) || this.defaultResponse
            };
        } catch (error) {
            console.error("NLP Analysis Error:", error);
            return {
                context: [],
                sentiment: {score: 0, sentiment: 'neutral'},
                entities: [],
                suggestedResponse: this.defaultResponse
            };
        }
    }

    // Helper method to generate responses based on sentiment
    generateSuggestedResponse(sentiment) {
        const responses = {
            positive: "I'm glad to hear that! How can I help you further?",
            negative: "I'm sorry to hear that. Let me know how I can help improve things.",
            neutral: "I understand. What would you like to know more about?"
        };
        return responses[sentiment] || responses.neutral;
    }
}

module.exports = new NLPUtils();
