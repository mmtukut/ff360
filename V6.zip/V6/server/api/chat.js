const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Access your API key as an environment variable
console.log("Gemini API Key:", process.env.GEMINI_API_KEY);
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-pro"});

router.post('/chat', async (req, res) => {
  try {
    console.log("Received chat request:", req.body);
    const message = req.body.message;

    if (!message) {
      console.error("Error: Message is missing in the request body");
      return res.status(400).json({ error: "Message is required" });
    }

    // Basic prompt - replace with a more sophisticated one later
    const prompt = `User: ${message}\nAI: `;

    const result = await model.generateContent(prompt);
    console.log("Gemini API Result:", result);
    const response = await result.response;
    console.log("Gemini API Response:", response);

    console.log("Sending response:", response.text());
    res.setHeader('Content-Type', 'application/json');
    res.json({ message: response.text() });

  } catch (error) {
    console.error("Chat API error:", error);
    console.error("Detailed error:", error);
    res.status(500).json({ error: "Error processing chat request" });
  }
});

router.get('/test', (req, res) => {
  res.json({ message: 'API is working' });
});

module.exports = router;