require('dotenv').config(); // Load environment variables from .env
const express = require('express');
const cors = require('cors');
const app = express();

// Enable CORS - Configure allowed origin(s)
const corsOptions = {
  origin: 'http://localhost:3000', // Allow requests from this origin
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE', // Specify allowed HTTP methods
  credentials: true, // Enable sending cookies from the server to the client
  optionsSuccessStatus: 204, // Some legacy browsers (IE11, various SmartTVs) choke on 204
};
app.use(cors(corsOptions));

// Parse JSON request bodies
app.use(express.json());

// Test endpoint - Verify server is running
app.get('/api/test', (req, res) => {
  res.status(200).json({ message: 'API is working' });
});

// Mount the chat API router
app.use('/api', require('./api/chat'));

// Error handling middleware - Handles errors for all routes
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(500).json({
    error: 'Server error',
    message: err.message,
  });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on port ${PORT}`);
}); 