import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../config/firebase';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import PropertyCard from './PropertyCard';
import { motion } from 'framer-motion';
import { Heart, Loader } from 'lucide-react';

const SavedProperties = () => {
  const { currentUser } = useAuth();
  const [savedProperties, setSavedProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSavedProperties = async () => {
      if (!currentUser) return;

      try {
        // Get user's saved property IDs
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        const savedPropertyIds = userDoc.data()?.savedProperties || [];

        if (savedPropertyIds.length === 0) {
          setSavedProperties([]);
          setLoading(false);
          return;
        }

        // Fetch full property details
        const propertiesRef = collection(db, 'properties');
        const q = query(propertiesRef, where('id', 'in', savedPropertyIds));
        const querySnapshot = await getDocs(q);
        
        const properties = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));

        setSavedProperties(properties);
      } catch (error) {
        console.error('Error fetching saved properties:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSavedProperties();
  }, [currentUser]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-[#1c5bde]" />
      </div>
    );
  }

  if (savedProperties.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center 
                      justify-center mx-auto mb-4">
          <Heart className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          No saved properties yet
        </h3>
        <p className="text-gray-600">
          Start saving properties you're interested in by clicking the heart icon
        </p>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
    >
      {savedProperties.map((property) => (
        <PropertyCard key={property.id} property={property} />
      ))}
    </motion.div>
  );
};

export default SavedProperties; 