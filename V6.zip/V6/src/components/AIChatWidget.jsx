import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, X, Send, Minimize2, Maximize2, 
  Building2, MapPin, Banknote, Home, Search,
  ChevronRight, ChevronLeft
} from 'lucide-react';
import { featuredProperties } from '../data/properties';
import { infrastructureData } from '../data/infrastructure';
import config from '../utils/config';
import { motion } from 'framer-motion';
import { preprocess } from '../utils/preprocess';
import * as tf from '@tensorflow/tfjs';
import createModel from '../utils/model';
import chatData from '../data/chat_data.json'; // Import the chat data
import { removeStopwords } from 'stopword';
import { oneHot } from '../utils/oneHot';

const API_URL = 'http://localhost:5000/api';
console.log("API_URL:", API_URL);

const AIChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatRef = useRef(null);
  const [position, setPosition] = useState({ right: '1rem', bottom: '5rem' });
  const [isDragging, setIsDragging] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [labelPosition, setLabelPosition] = useState('left');
  const [model, setModel] = useState(null);
  const [suggestions, setSuggestions] = useState([]);

  const [promptSuggestions] = useState([
    {
      text: "Find properties in Gombe under ₦5M",
      category: "price",
      icon: Banknote
    },
    {
      text: "Show luxury homes in Gombe GRA",
      category: "property",
      icon: Home
    },
    {
      text: "What's the infrastructure like near Federal College?",
      category: "infrastructure",
      icon: Building2
    },
    {
      text: "Properties near Gombe State University",
      category: "education",
      icon: Search
    },
    {
      text: "Commercial spaces in Gombe CBD",
      category: "commercial",
      icon: Building2
    },
    {
      text: "3 bedroom apartments in Tumfure",
      category: "residential",
      icon: Home
    }
  ]);

  const [chatHistory, setChatHistory] = useState([
    {
      type: 'bot',
      content: "Hello! I'm FastFind AI. How can I help you find your perfect property in Gombe today?"
    }
  ]);

  const [visibleSuggestions, setVisibleSuggestions] = useState([0, 1, 2]);
  const [suggestionPage, setSuggestionPage] = useState(0);

  // Handle dragging
  const handleMouseDown = (e) => {
    if (e.target.closest('.chat-controls')) return;
    setIsDragging(true);
    setStartPos({
      x: e.clientX - parseFloat(position.right),
      y: e.clientY - parseFloat(position.bottom)
    });
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    
    const newRight = Math.max(0, startPos.x - e.clientX);
    const newBottom = Math.max(0, startPos.y - e.clientY);
    
    setPosition({
      right: `${newRight}px`,
      bottom: `${newBottom}px`
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Rotate through suggestions
  const handleNextSuggestions = () => {
    setSuggestionPage(prev => (prev + 1) % Math.ceil(promptSuggestions.length / 3));
  };

  const handlePrevSuggestions = () => {
    setSuggestionPage(prev => 
      prev === 0 ? Math.ceil(promptSuggestions.length / 3) - 1 : prev - 1
    );
  };

  useEffect(() => {
    const startIdx = suggestionPage * 3;
    setVisibleSuggestions([startIdx, startIdx + 1, startIdx + 2]);
  }, [suggestionPage]);

  // Process AI Response
  const processAIResponse = async (message) => {
    setIsTyping(true);
    try {
      const response = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message }),
      });

      const data = await response.json();
      console.log('Response from /chat:', data); // Log the response

      setTimeout(() => {
        setChatHistory(prev => [...prev, { type: 'bot', content: data.message }]); // Use the test message
        setIsTyping(false);
      }, 500);

    } catch (error) {
      console.error("API Error:", error);
      setChatHistory(prev => [...prev, { type: 'bot', content: "Sorry, I encountered an error. Please try again." }]);
      setIsTyping(false);
    }
  };

  // Add this to control visibility based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const button = document.querySelector('.ai-chat-button');
      if (button) {
        if (scrollPosition > 100) {
          button.style.opacity = '0.6';
        } else {
          button.style.opacity = '1';
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Add this effect to check screen position
  useEffect(() => {
    const checkPosition = () => {
      const button = document.querySelector('.ai-chat-button');
      if (button) {
        const rect = button.getBoundingClientRect();
        const spaceOnRight = window.innerWidth - rect.right;
        setLabelPosition(spaceOnRight < 200 ? 'left' : 'right');
      }
    };

    checkPosition();
    window.addEventListener('resize', checkPosition);
    return () => window.removeEventListener('resize', checkPosition);
  }, [position]);

  useEffect(() => {
    const testPreprocessing = () => {
      const testText = "Find properties in Gombe under ₦5M";
      const preprocessedText = preprocess(testText);
      console.log('Original Text:', testText);
      console.log('Preprocessed Text:', preprocessedText);

    };
    testPreprocessing();
  }, []);

  // Model parameters
  const embeddingDimension = 20;
  const sequenceLength = 20; // Increased sequence length
  const epochs = 10;
  const rnnUnits = 128;

  // State variables for vocabulary and intents
  const [vocabulary, setVocabulary] = useState([]);
  const [wordToIndex, setWordToIndex] = useState({});
  const [indexToWord, setIndexToWord] = useState({});
  const [intents, setIntents] = useState([]);
  const [intentToIndex, setIntentToIndex] = useState({});
  const [indexToIntent, setIndexToIntent] = useState({});

  // Training data
  const chatData = [
    { query: "find properties in Gombe", intent: "property_search" },
    { query: "What is the price range in Gombe?", intent: "price_range" },
    { query: "Are there houses for sale in Gombe?", intent: "property_search" },
    { query: "I am looking for an apartment in Gombe?", intent: "property_search" },
    { query: "What schools are near these properties?", intent: "school_info" },
    { query: "Tell me about the neighborhood", intent: "neighborhood_info" },
    { query: "Is it close to the airport?", intent: "airport_distance" },
    { query: "What is the average income?", intent: "income_info" },
    { query: "What is the population?", intent: "population_info" },
    { query: "Are there any hospitals nearby?", intent: "hospital_info" },
    { query: "What are the crime rates?", intent: "crime_rates" },
    { query: "How is the public transportation?", intent: "transportation_info" },
    { query: "Are there any parks?", intent: "park_info" },
    { query: "What are the main industries?", intent: "industry_info" },
    { query: "What are some local attractions?", intent: "attraction_info" },
    { query: "What are the property taxes?", intent: "property_taxes" },
    { query: "What are the best restaurants?", intent: "restaurant_recommendation" },
    { query: "How is the weather?", intent: "weather_info" },
    { query: "What are the demographics?", intent: "demographics_info" },
    { query: "What are the major employers?", intent: "major_employers" },
    { query: "find properties in kasoa", intent: "property_search" },
    { query: "What is the price range in kasoa?", intent: "price_range" },
    { query: "Are there houses for sale in kasoa?", intent: "property_search" },
    { query: "I am looking for an apartment in kasoa?", intent: "property_search" },
    { query: "What schools are near these properties in kasoa?", intent: "school_info" },
    { query: "Tell me about the kasoa neighborhood", intent: "neighborhood_info" },
    { query: "Is it close to the airport?", intent: "airport_distance" },
    { query: "What is the average income?", intent: "income_info" },
    { query: "What is the population?", intent: "population_info" },
    { query: "Are there any hospitals nearby?", intent: "hospital_info" },
    { query: "What are the crime rates?", intent: "crime_rates" },
    { query: "How is the public transportation?", intent: "transportation_info" },
    { query: "Are there any parks?", intent: "park_info" },
    { query: "What are the main industries?", intent: "industry_info" },
    { query: "What are some local attractions?", intent: "attraction_info" },
    { query: "What are the property taxes?", intent: "property_taxes" },
    { query: "What are the best restaurants?", intent: "restaurant_recommendation" },
    { query: "How is the weather?", intent: "weather_info" },
    { query: "What are the demographics?", intent: "demographics_info" },
    { query: "What are the major employers?", intent: "major_employers" },
    { query: "I want to buy a house", intent: "property_search" },
    { query: "rent apartment", intent: "property_search" },
    { query: "house price", intent: "price_range" },
    { query: "nearby schools", intent: "school_info" },
    { query: "tell me about area", intent: "neighborhood_info" },
    { query: "distance to airport", intent: "airport_distance" },
    { query: "average salary", intent: "income_info" },
    { query: "population size", intent: "population_info" },
    { query: "local hospitals", intent: "hospital_info" },
    { query: "crime statistics", intent: "crime_rates" },
    { query: "transportation options", intent: "transportation_info" },
    { query: "parks around here", intent: "park_info" },
    { query: "main business", intent: "industry_info" },
    { query: "tourist spots", intent: "attraction_info" },
    { query: "real estate tax", intent: "property_taxes" },
    { query: "good places to eat", intent: "restaurant_recommendation" },
    { query: "climate like", intent: "weather_info" },
    { query: "who lives here", intent: "demographics_info" },
    { query: "biggest companies", intent: "major_employers" },
    { query: "find houses", intent: "property_search" },
    { query: "find apartments", intent: "property_search" },
    { query: "properties for sale", intent: "property_search" },
    { query: "properties for rent", intent: "property_search" },
    { query: "how much does it cost to live here", intent: "price_range" },
    { query: "what is the cost of living", intent: "price_range" },
    { query: "are there good schools", intent: "school_info" },
    { query: "what are the schools like", intent: "school_info" },
    { query: "describe the neighborhood", intent: "neighborhood_info" },
    { query: "what is the area like", intent: "neighborhood_info" },
    { query: "how far from the airport", intent: "airport_distance" },
    { query: "what is the distance to the airport", intent: "airport_distance" },
    { query: "what do people earn here", intent: "income_info" },
    { query: "what is the average income", intent: "income_info" },
    { query: "how many people live here", intent: "population_info" },
    { query: "what is the population", intent: "population_info" },
    { query: "where can i find hospitals", intent: "hospital_info" }, 
    { query: "are there any good hospitals", intent: "hospital_info" },
    { query: "is it safe here", intent: "crime_rates" },
    { query: "is it dangerous", intent: "crime_rates" },
    { query: "how do people get around", intent: "transportation_info" },
    { query: "is there public transport", intent: "transportation_info" },
    { query: "are there parks nearby", intent: "park_info" },
    { query: "what are the parks like", intent: "park_info" },
    { query: "what are the main businesses", intent: "industry_info" },
    { query: "what are the main industries", intent: "industry_info" },
    { query: "what are the tourist spots", intent: "attraction_info" },
    { query: "what are the local attractions", intent: "attraction_info" },
    { query: "how much is the real estate tax", intent: "property_taxes" },
    { query: "what is the property tax rate", intent: "property_taxes" },
    { query: "where can i find good restaurants", intent: "restaurant_recommendation" },
    { query: "what are the best places to eat", intent: "restaurant_recommendation" },
    { query: "what is the climate like", intent: "weather_info" },
    { query: "what is the weather like", intent: "weather_info" },
    { query: "tell me the demographics", intent: "demographics_info" },
    { query: "who lives here", intent: "demographics_info" },
    { query: "what are the biggest companies", intent: "major_employers" },
    { query: "what are the major employers", intent: "major_employers" }
  ];

  const prepareData = async () => {
    // Extract queries and intents from chatData
    const queries = chatData.map(item => item.query);
    const intentsList = chatData.map(item => item.intent);

    // 1. Build Vocabulary
    const allTokens = queries.map(query => preprocess(query)).flat();
    const newVocabulary = [...new Set(allTokens)]; // Unique tokens
    const newWordToIndex = Object.fromEntries(newVocabulary.map((word, index) => [word, index]));
    const newIndexToWord = Object.fromEntries(newVocabulary.map((word, index) => [index, word]));

    // 2. Build Intent mappings
    const newIntents = [...new Set(intentsList)];
    const newIntentToIndex = Object.fromEntries(newIntents.map((intent, index) => [intent, index]));
    const newIndexToIntent = Object.fromEntries(newIntents.map((intent, index) => [index, intent]));

    // Convert queries to sequences of numbers
    const sequences = queries.map(query => {
      const preprocessedQuery = preprocess(query);
      return preprocessedQuery.map(token => newWordToIndex[token] || 0); // 0 for unknown words
    });

    // Pad sequences
    const paddedSequences = sequences.map(sequence => {
      const paddedSequence = sequence.slice(0, 1); // sequenceLength);
      while (paddedSequence.length < 1) {
        paddedSequence.push(0);
      }
      return paddedSequence;
    });

    // Convert padded sequences to a TensorFlow tensor
    const xs = tf.tensor2d(paddedSequences, [paddedSequences.length, 1]);

    // Convert intents to one-hot vectors
    const ys = intentsList.map(intent => {
      const index = newIntentToIndex[intent];
      console.log("Intent Index:", index, "Intent Length:", newIntents.length);
      return oneHot(index, newIntents.length);
    });

    // Convert one-hot vectors to a TensorFlow tensor
    console.log("YS:", ys);
    if (ys.length === 0) {
      console.error("Error: ys is empty!");
      return { trainingXs: null, trainingYs: null, validationXs: null, validationYs: null, vocabulary: newVocabulary, intents: newIntents };
    }
    let oneHotYs;
    try {
      oneHotYs = tf.tensor2d(ys, [ys.length, newIntents.length]);
    } catch (error) {
      console.error("Error creating oneHotYs tensor:", error);
      console.log("ys:", ys);
      return { trainingXs: null, trainingYs: null, validationXs: null, validationYs: null, vocabulary: newVocabulary, intents: newIntents };
    }

    // Split data into training and validation sets (80/20 split)
    const splitIndex = Math.floor(xs.shape[0] * 0.8);
    const trainingXs = xs.slice([0, 0], [splitIndex, 1]);
    const trainingYs = oneHotYs.slice([0, 0], [splitIndex, newIntents.length]);
    const validationXs = xs.slice([splitIndex, 0], [xs.shape[0] - splitIndex, 1]);
    const validationYs = oneHotYs.slice([splitIndex, 0], [xs.shape[0] - splitIndex, newIntents.length]);

    setVocabulary(newVocabulary);
    setWordToIndex(newWordToIndex);
    setIndexToWord(newIndexToWord);
    setIntents(newIntents);
    setIntentToIndex(newIntentToIndex);
    setIndexToIntent(newIndexToIntent);

    return { trainingXs, trainingYs, validationXs, validationYs, vocabulary: newVocabulary, intents: newIntents };
  };

  const learningRate = 0.01;

  const trainModel = async (vocabulary, embeddingDimension, intents, trainingXs, trainingYs, validationXs, validationYs) => {
    console.log("Vocabulary Length:", vocabulary.length);
    console.log("Embedding Dimension:", embeddingDimension);
    console.log("Number of Intents:", intents.length);

    // Create the model
    const model = createModel(vocabulary.length, embeddingDimension, intents.length, learningRate);

    // Train the model
    await model.fit(trainingXs, trainingYs, {
      epochs: epochs,
      validationData: [validationXs, validationYs],
      callbacks: {
        onEpochEnd: async (epoch, logs) => {
          console.log(`Epoch: ${epoch} Loss: ${logs.loss} Accuracy: ${logs.acc} Validation Loss: ${logs.val_loss} Validation Accuracy: ${logs.val_acc}`);
        }
      }
    });

    setChatHistory(prevHistory => [...prevHistory, { text: "Training complete!", sender: "bot" }]);
    setModel(model);
  };

  useEffect(() => {
    const loadModelAndTrain = async () => {
      tf.ready().then(() => {
        console.log("TensorFlow.js is ready");
      });

      prepareData().then(({ trainingXs, trainingYs, validationXs, validationYs, vocabulary, intents }) => {
        if (vocabulary.length > 0) {
          if (!trainingXs || !trainingYs || !validationXs || !validationYs) {
            console.error("One or more of trainingXs, trainingYs, validationXs, or validationYs is null.");
            return;
          }
          trainModel(vocabulary, embeddingDimension, intents, trainingXs, trainingYs, validationXs, validationYs);
        } else {
          console.error("Vocabulary is empty. Model cannot be trained.");
        }
      });
    };

    loadModelAndTrain();
  }, []);

  const handleSendMessage = async () => {
    if (message.trim()) {
      setChatHistory(prevHistory => [...prevHistory, { type: 'user', content: message }]);
      processAIResponse(message);
      setMessage(''); // Clear the input after sending
    }
  };

  return (
    <div 
      className="fixed z-50"
      style={position}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Chat Button - Updated Design */}
      {!isOpen && (
        <motion.div className="relative">
          <motion.button
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.05 }}
            onClick={() => setIsOpen(true)}
            className="group ai-chat-button bg-white/80 hover:bg-white text-[#1c5bde] rounded-full p-3 
                     shadow-lg transition-all duration-200 backdrop-blur-sm border border-gray-100 relative"
          >
            <MessageCircle className="h-5 w-5" />
            <span 
              className={`absolute top-1/2 -translate-y-1/2 bg-white px-3 py-1.5 
                         rounded-lg text-sm font-medium shadow-lg opacity-0 group-hover:opacity-100 
                         transition-opacity duration-200 whitespace-nowrap pointer-events-none
                         ${labelPosition === 'left' 
                           ? 'right-[calc(100%+0.75rem)]' 
                           : 'left-[calc(100%+0.75rem)]'}`}
            >
              Ask FastFind AI
            </span>
          </motion.button>
        </motion.div>
      )}

      {/* Chat Window - When Open */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          ref={chatRef}
          className={`bg-white rounded-lg shadow-2xl transition-all duration-200 backdrop-blur-sm 
            ${isMinimized ? 'h-14' : 'h-[500px]'} w-[350px] flex flex-col`}
        >
          {/* Header */}
          <div className="p-3 bg-gradient-to-r from-[#1c5bde] to-[#0c0d8a] text-white 
                        rounded-t-lg flex justify-between items-center chat-controls">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              FastFind AI Assistant
            </h3>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="hover:bg-white/20 p-1.5 rounded transition-colors"
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="hover:bg-white/20 p-1.5 rounded transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Chat History */}
          <div className="flex-1 overflow-y-auto p-4">
            {chatHistory.map((msg, index) => (
              <div key={index} className={`mb-2 ${msg.type === 'user' ? 'text-right' : 'text-left'}`}>
                <div className={`inline-block rounded-xl p-2 text-sm ${msg.type === 'user' ? 'bg-[#1c5bde] text-white' : 'bg-gray-100 text-gray-700'}`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="text-left">
                <div className="bg-gray-100 rounded-lg p-3">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Suggestions */}
          <div className="p-4 border-t border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-500">Suggestions</span>
            </div>
            <div className="flex overflow-x-auto space-x-2">
              {promptSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setMessage(suggestion.text);
                    setChatHistory(prev => [...prev, { type: 'user', content: suggestion.text }]);
                    processAIResponse(suggestion.text);
                  }}
                  className="text-left text-sm text-gray-600 hover:text-[#1c5bde] hover:bg-[#1c5bde]/5 p-2 rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap"
                >
                  {React.createElement(suggestion.icon, { className: "h-4 w-4" })}
                  {suggestion.text}
                </button>
              ))}
            </div>

            {/* Input Field */}
            <div className="flex gap-2 mt-4">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && message.trim() && handleSendMessage()}
                placeholder="Type your question..."
                className="flex-1 border rounded-lg px-3 py-2 focus:outline-none focus:border-[#1c5bde] text-sm"
              />
              <button
                onClick={handleSendMessage}
                className="bg-gradient-to-r from-[#1c5bde] to-[#0c0d8a] text-white rounded-lg px-4 py-2 hover:opacity-90 transition-opacity"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default AIChatWidget;