import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Send, Loader2, MessageCircle, User, X, Minimize2, Maximize2, Building2, MapPin, Banknote, Home, MessageSquareText } from 'lucide-react';

const AIChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const [isTyping, setIsTyping] = useState(false);
  const suggestionsRef = useRef(null);
  const navigate = useNavigate();
  const widgetRef = useRef(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{
        type: 'assistant',
        content: "👋 Hello! I'm your FastFind AI assistant. I can help you:\n\n" +
                "• Find properties that match your preferences\n" +
                "• Answer questions about specific properties\n" +
                "• Provide detailed information about locations\n" +
                "• Compare different properties\n\n" +
                "How can I assist you today?",
        timestamp: new Date()
      }]);
    }
  }, [isOpen]);

  useEffect(() => {
    window.handlePropertyChat = (propertyId, propertyTitle) => {
      const message = `Tell me more about "${propertyTitle}"`;
      setInputMessage('');
      setMessages(prev => [...prev, {
        type: 'user',
        content: message,
        timestamp: new Date()
      }]);
      
      handleSubmit(
        { preventDefault: () => {} },
        message,
        propertyId
      );
      
      setIsOpen(true);
      setIsMinimized(false);
    };

    return () => {
      delete window.handlePropertyChat;
    };
  }, []);

  const suggestions = [
    {
      text: "Find properties under ₦5M",
      icon: Banknote,
      category: "price"
    },
    {
      text: "Show luxury homes",
      icon: Home,
      category: "luxury"
    },
    {
      text: "Properties near schools",
      icon: Building2,
      category: "education"
    },
    {
      text: "Commercial spaces",
      icon: Building2,
      category: "commercial"
    },
    {
      text: "2 bedroom apartments",
      icon: Home,
      category: "residential"
    },
    {
      text: "Properties with pool",
      icon: Home,
      category: "amenities"
    }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const formatPropertySection = (property) => {
    if (!property) return '';
    
    const features = property.features || [];
    const title = property.title?.replace(/[\[\]]/g, '') || 'Property'; // Remove brackets from title
    
    return `
      <div class="property-card bg-white rounded-lg p-4 mb-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
        <div class="flex items-start gap-4">
          <img src="${property.image || '/placeholder.jpg'}" alt="${title}" class="w-24 h-24 rounded-lg object-cover" />
          <div class="flex-1">
            <h3 class="font-semibold text-lg mb-1">${title}</h3>
            <div class="flex items-center gap-2 text-gray-600 mb-2">
              <span class="flex items-center gap-1">
                <i class="fas fa-map-marker-alt"></i>
                ${property.location || 'Location not specified'}
              </span>
              <span class="text-green-600 font-semibold">₦${(property.price || 0).toLocaleString()}</span>
            </div>
            <div class="flex flex-wrap gap-2 mb-3">
              ${features.map(feature => 
                `<span class="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">${feature}</span>`
              ).join('')}
            </div>
            <div class="flex items-center gap-3">
              <a 
                href="/properties/${property.id}"
                class="inline-block px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                View Details
              </a>
              <button 
                onclick="handlePropertyChat(${property.id})" 
                class="inline-flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                <MessageSquareText class="w-4 h-4" />
                Chat About This
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  };

  const formatMessage = (text, properties = []) => {
    if (Array.isArray(properties) && properties.length > 0) {
      const propertyCards = properties.map(formatPropertySection).join('');
      text = text.replace('[PROPERTY_SECTION]', propertyCards);
    }

    const processedText = text
      .replace(
        /\[([^\]]+)\]\(\/properties\/(\d+)\)/g,
        `<a href="/properties/$2" class="text-blue-500 hover:text-blue-700 font-medium property-link">[$1]</a>`
      )
      .replace(
        /\[([^\]]+)\]\(\/chat\?propertyId=(\d+)\)/g,
        `<button onclick="handlePropertyChat($2)" class="text-green-500 hover:text-green-700 font-medium">Chat about this property</button>`
      )
      .replace(
        /(₦\d{1,3}(,\d{3})*(\.\d{1,2})?)/g,
        '<span class="text-green-600 font-semibold">$1</span>'
      )
      .replace(
        /\*\*(.*?)\*\*/g,
        '<strong>$1</strong>'
      )
      .replace(/\n/g, '<br />')
      .replace(
        /[\[\]]/g,
        ''
      )
      .replace(
        /- View Details\(\/properties\/(\d+)\)/g,
        `<button onclick="window.location.href='/properties/$1'" class="text-blue-500 hover:text-blue-700 font-medium">View Details</button>`
      );

    return (
      <div 
        dangerouslySetInnerHTML={{ __html: processedText }}
        className="prose prose-sm max-w-none"
        onClick={(e) => {
          if (e.target.closest('.property-link')) {
            e.preventDefault();
            const link = e.target.closest('.property-link');
            const href = link.getAttribute('href');
            navigate(href);
          }
        }}
      />
    );
  };

  const handleSuggestionClick = (suggestion) => {
    handleSubmit({ preventDefault: () => {} }, suggestion.text);
  };

  const handleSubmit = async (e, suggestionText = null, propertyId = null) => {
    e.preventDefault();
    const messageText = suggestionText || inputMessage;
    if (!messageText.trim()) return;

    if (!suggestionText) {
      setMessages(prev => [...prev, {
        type: 'user',
        content: messageText,
        timestamp: new Date()
      }]);
    }
    
    setInputMessage('');
    setIsLoading(true);
    setIsTyping(true);

    try {
      const response = await fetch('http://localhost:5000/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: messageText,
          userId: 'user123',
          propertyId: propertyId
        }),
      });

      const data = await response.json();
      
      setTimeout(() => {
        setMessages(prev => [...prev, {
          type: 'assistant',
          content: data.message,
          analysis: data.analysis,
          properties: data.properties || [],
          timestamp: new Date()
        }]);
        setIsTyping(false);
      }, 500);

    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        type: 'assistant',
        content: 'I apologize, but I encountered an error. Please try again.',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  };

  const MessageContent = ({ message }) => {
    return formatMessage(message.content, message.properties);
  };

  if (!isOpen) {
    return (
      <motion.button
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-blue-500 text-white px-4 py-2 rounded-lg shadow-lg hover:bg-blue-600 transition-colors group flex items-center gap-2"
      >
        <MessageSquareText className="w-5 h-5" />
        <span className="font-medium">AI</span>
      </motion.button>
    );
  }

  return (
    <motion.div
      ref={widgetRef}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className={`fixed ${isMinimized ? 'bottom-4 right-4 w-auto h-auto' : 'bottom-4 right-4 w-96 h-[600px]'} 
                 bg-white rounded-lg shadow-xl flex flex-col transition-all duration-300`}
    >
      {/* Header */}
      <div className="p-4 bg-blue-500 text-white rounded-t-lg flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquareText className="w-5 h-5" />
          <span className="font-medium">FastFind AI Assistant</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-blue-600 rounded"
          >
            {isMinimized ? <Maximize2 className="w-5 h-5" /> : <Minimize2 className="w-5 h-5" />}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-blue-600 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <AnimatePresence>
              {messages.map((msg, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className={`flex items-start gap-3 ${
                    msg.type === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {msg.type === 'assistant' && (
                    <div className="flex-shrink-0">
                      <MessageSquareText className="w-8 h-8 text-blue-500" />
                    </div>
                  )}
                  
                  <motion.div
                    className={`relative max-w-[80%] rounded-2xl p-4 ${
                      msg.type === 'user'
                        ? 'bg-blue-500 text-white'
                        : 'bg-white shadow-md'
                    }`}
                    whileHover={{ scale: 1.01 }}
                    transition={{ type: 'spring', stiffness: 300 }}
                  >
                    <MessageContent message={msg} />
                    
                    {msg.type === 'assistant' && msg.analysis && (
                      <div className="mt-2 pt-2 border-t border-gray-100 text-xs text-gray-500">
                        <div>Sentiment: {msg.analysis.sentiment.sentiment}</div>
                        {msg.analysis.entities?.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {msg.analysis.entities.map((entity, i) => (
                              <span
                                key={i}
                                className="px-1.5 py-0.5 bg-gray-100 rounded-full text-gray-600"
                              >
                                {entity.type}: {entity.text}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>

                  {msg.type === 'user' && (
                    <div className="flex-shrink-0">
                      <User className="w-8 h-8 text-blue-500" />
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 text-gray-500"
              >
                <MessageSquareText className="w-8 h-8 text-blue-500" />
                <div className="flex gap-1">
                  <motion.div
                    className="w-2 h-2 bg-blue-500 rounded-full"
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-blue-500 rounded-full"
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, delay: 0.1 }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-blue-500 rounded-full"
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, delay: 0.2 }}
                  />
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggestions */}
          <div className="p-4 border-t border-gray-100">
            <div className="text-sm text-gray-500 mb-2">Suggestions:</div>
            <div 
              ref={suggestionsRef}
              className="flex overflow-x-auto space-x-2 pb-2 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent"
            >
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="flex-shrink-0 flex items-center gap-2 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 
                           rounded-full text-sm text-gray-700 transition-colors whitespace-nowrap"
                >
                  <suggestion.icon className="w-4 h-4" />
                  {suggestion.text}
                </button>
              ))}
            </div>
          </div>

          {/* Input Form */}
          <form
            onSubmit={handleSubmit}
            className="p-4 border-t border-gray-200 bg-white rounded-b-lg"
          >
            <div className="flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 px-4 py-2 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={isLoading}
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                type="submit"
                disabled={isLoading || !inputMessage.trim()}
                className={`px-4 py-2 rounded-full bg-blue-500 text-white flex items-center gap-2 
                           ${isLoading || !inputMessage.trim() ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-600'}`}
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </motion.button>
            </div>
          </form>
        </>
      )}
    </motion.div>
  );
};

export default AIChatWidget;