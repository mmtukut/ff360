import React, { useEffect, useState } from 'react';
import { Star, Heart, Bed, Bath, Square, MapPin, Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import { getDoc, doc } from 'firebase/firestore';
import { db } from '../config/firebase';

const PropertyCard = ({ property, onSaveChange }) => {
  const { currentUser, saveProperty, removeSavedProperty } = useAuth();
  const [isSaved, setIsSaved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Check if property is saved when component mounts
  useEffect(() => {
    const checkIfSaved = async () => {
      if (!currentUser) return;
      
      try {
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        const savedProperties = userDoc.data()?.savedProperties || [];
        setIsSaved(savedProperties.includes(property.id));
      } catch (error) {
        console.error('Error checking saved status:', error);
      }
    };

    checkIfSaved();
  }, [currentUser, property.id]);

  const handleSaveProperty = async (e) => {
    e.stopPropagation(); // Prevent card click event

    if (!currentUser) {
      toast.error('Please login to save properties');
      return;
    }

    setIsLoading(true);
    try {
      if (isSaved) {
        await removeSavedProperty(property.id);
        setIsSaved(false);
        toast.success('Property removed from saved list');
      } else {
        await saveProperty(property.id);
        setIsSaved(true);
        toast.success('Property saved successfully');
      }
      
      // Trigger a refresh of the saved count
      if (onSaveChange) {
        onSaveChange();
      }
      
    } catch (error) {
      console.error('Error saving property:', error);
      toast.error('Failed to save property');
    } finally {
      setIsLoading(false);
    }
  };

  const {
    images,
    title,
    type,
    price,
    rating,
    reviews,
    location,
    amenities,
    verificationBadge,
    beds,
    baths,
    area,
    availability,
    furnished,
    propertyCondition
  } = property;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group cursor-pointer bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
    >
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={images[0]}
          alt={title}
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/400x300?text=No+Image';
          }}
        />
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={handleSaveProperty}
          disabled={isLoading}
          className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-md hover:shadow-lg transition-all duration-300"
        >
          <Heart
            className={`w-5 h-5 ${
              isSaved ? 'fill-red-500 text-red-500' : 'text-gray-600'
            }`}
          />
        </motion.button>
        {verificationBadge && (
          <div className="absolute top-4 left-4 bg-blue-500 text-white px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1">
            <Check className="w-3 h-3" />
            Verified
          </div>
        )}
        <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
          <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-gray-900">
            {type}
          </div>
          <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium text-gray-900 flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-400" />
            {rating} ({reviews} reviews)
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
            {title}
          </h3>
          <p className="text-lg font-bold text-blue-600 whitespace-nowrap">
            ₦{price.toLocaleString()}
          </p>
        </div>

        <div className="flex items-center gap-2 text-gray-500 mb-3">
          <MapPin className="w-4 h-4" />
          <p className="text-sm">{location}</p>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="flex items-center gap-1 text-gray-600">
            <Bed className="w-4 h-4" />
            <span className="text-sm">{beds} Beds</span>
          </div>
          <div className="flex items-center gap-1 text-gray-600">
            <Bath className="w-4 h-4" />
            <span className="text-sm">{baths} Baths</span>
          </div>
          <div className="flex items-center gap-1 text-gray-600">
            <Square className="w-4 h-4" />
            <span className="text-sm">{area}m²</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {amenities.slice(0, 3).map((amenity, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-gray-100 rounded-full text-xs text-gray-600"
            >
              {amenity}
            </span>
          ))}
          {amenities.length > 3 && (
            <span className="px-2 py-1 bg-gray-100 rounded-full text-xs text-gray-600">
              +{amenities.length - 3} more
            </span>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`px-2 py-1 rounded-full text-xs ${
              availability === 'Available' 
                ? 'bg-green-100 text-green-700'
                : 'bg-red-100 text-red-700'
            }`}>
              {availability}
            </span>
            {furnished && (
              <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                Furnished
              </span>
            )}
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => window.open(`/chat?propertyId=${property.id}`, '_blank')}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Chat about this property
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default PropertyCard;