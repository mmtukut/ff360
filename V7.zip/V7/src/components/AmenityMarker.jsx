import React from 'react';
import { motion } from 'framer-motion';

export const AmenityMarker = ({ type, name, distance }) => {
  const getIcon = () => {
    switch (type) {
      case 'school':
        return '🏫';
      case 'hospital':
        return '🏥';
      case 'restaurant':
        return '🍽️';
      case 'transit':
        return '🚉';
      default:
        return '📍';
    }
  };

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="relative group"
    >
      <div className="bg-white rounded-full p-2 shadow-lg cursor-pointer
                    transform transition-transform group-hover:scale-110">
        <span className="text-lg">{getIcon()}</span>
      </div>
      <div className="absolute -top-8 left-1/2 -translate-x-1/2 
                    bg-black text-white px-2 py-1 rounded text-sm whitespace-nowrap
                    opacity-0 group-hover:opacity-100 transition-opacity">
        {name} ({distance}m)
      </div>
    </motion.div>
  );
}; 