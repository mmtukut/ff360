import React, { createContext, useContext, useState, useEffect } from 'react';
import { db } from '../config/firebase';
import { doc, getDoc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { useAuth } from './AuthContext';

const SavedPropertiesContext = createContext();

export const useSavedProperties = () => {
  const context = useContext(SavedPropertiesContext);
  if (!context) {
    throw new Error('useSavedProperties must be used within a SavedPropertiesProvider');
  }
  return context;
};

export const SavedPropertiesProvider = ({ children }) => {
  const [savedProperties, setSavedProperties] = useState([]);
  const { currentUser } = useAuth();

  // Fetch saved properties when user changes
  useEffect(() => {
    const fetchSavedProperties = async () => {
      if (!currentUser) {
        setSavedProperties([]);
        return;
      }

      try {
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        const savedIds = userDoc.data()?.savedProperties || [];
        setSavedProperties(savedIds);
      } catch (error) {
        console.error('Error fetching saved properties:', error);
      }
    };

    fetchSavedProperties();
  }, [currentUser]);

  // Check if a property is saved
  const isSaved = (propertyId) => {
    return savedProperties.includes(propertyId);
  };

  // Toggle save property
  const toggleSaveProperty = async (propertyId) => {
    if (!currentUser) {
      // Handle not logged in state - maybe show login prompt
      return;
    }

    const userRef = doc(db, 'users', currentUser.uid);

    try {
      if (isSaved(propertyId)) {
        // Remove from saved
        await updateDoc(userRef, {
          savedProperties: arrayRemove(propertyId)
        });
        setSavedProperties(prev => prev.filter(id => id !== propertyId));
      } else {
        // Add to saved
        await updateDoc(userRef, {
          savedProperties: arrayUnion(propertyId)
        });
        setSavedProperties(prev => [...prev, propertyId]);
      }
    } catch (error) {
      console.error('Error toggling saved property:', error);
    }
  };

  const value = {
    savedProperties,
    isSaved,
    toggleSaveProperty
  };

  return (
    <SavedPropertiesContext.Provider value={value}>
      {children}
    </SavedPropertiesContext.Provider>
  );
}; 