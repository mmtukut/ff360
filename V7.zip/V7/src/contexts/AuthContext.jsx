import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  sendEmailVerification,
  sendSignInLinkToEmail
} from 'firebase/auth';
import { auth, googleProvider, db } from '../config/firebase';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { toast } from 'react-hot-toast';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Sign Up
  async function signup(email, password, additionalData) {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Send verification email
      await verifyEmail(user);

      await updateProfile(user, {
        displayName: additionalData.name
      });

      await setDoc(doc(db, 'users', user.uid), {
        email,
        phone: additionalData.phone,
        accountType: additionalData.accountType,
        createdAt: serverTimestamp(),
        emailVerified: false,
        savedProperties: [],
        searchHistory: [],
        preferences: {
          notifications: true,
          newsletter: true
        }
      });

      toast.success('Account created successfully!');
      return userCredential;
    } catch (error) {
      console.error('Signup error:', error);
      toast.error(error.message);
      throw error;
    }
  }

  // Sign In
  async function login(email, password) {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      toast.success('Welcome back!');
      return result.user;
    } catch (error) {
      console.error('Login error:', error);
      toast.error(error.message);
      throw error;
    }
  }

  // Google Login
  async function googleLogin() {
    try {
      // Configure popup settings
      googleProvider.setCustomParameters({
        prompt: 'select_account',
        display: 'popup'
      });

      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      
      // Check if user document exists
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      
      if (!userDoc.exists()) {
        await setDoc(doc(db, 'users', user.uid), {
          email: user.email,
          name: user.displayName,
          createdAt: serverTimestamp(),
          emailVerified: user.emailVerified,
          profileCompleted: false,
          savedProperties: [],
          searchHistory: [],
          preferences: {
            notifications: true,
            newsletter: true
          }
        });
        
        return { user, needsProfile: true };
      }

      const userData = userDoc.data();
      return { user, needsProfile: !userData.profileCompleted };
    } catch (error) {
      console.error('Google login error:', error);
      
      // Handle specific error cases
      if (error.code === 'auth/popup-closed-by-user') {
        throw new Error('Sign-in window was closed. Please try again.');
      } else if (error.code === 'auth/popup-blocked') {
        throw new Error('Pop-up was blocked. Please allow pop-ups for this site.');
      } else if (error.code === 'auth/network-request-failed') {
        throw new Error('Network error. Please check your internet connection.');
      }
      
      throw error;
    }
  }

  // Sign Out
  async function logout() {
    try {
      await signOut(auth);
      toast.success('Signed out successfully');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error(error.message);
      throw error;
    }
  }

  // Reset Password
  async function resetPassword(email) {
    try {
      await sendPasswordResetEmail(auth, email);
      toast.success('Password reset email sent!');
    } catch (error) {
      console.error('Password reset error:', error);
      toast.error(error.message);
      throw error;
    }
  }

  // Add email verification function
  async function verifyEmail(user) {
    try {
      await sendEmailVerification(user);
      toast.success('Verification email sent!');
    } catch (error) {
      console.error('Email verification error:', error);
      toast.error(error.message);
      throw error;
    }
  }

  // Add function to check verification status
  async function checkEmailVerification() {
    if (currentUser) {
      await currentUser.reload();
      return currentUser.emailVerified;
    }
    return false;
  }

  // Add function to resend verification email
  async function resendVerificationEmail() {
    if (currentUser && !currentUser.emailVerified) {
      await verifyEmail(currentUser);
    }
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const value = {
    currentUser,
    signup,
    login,
    googleLogin,
    logout,
    resetPassword,
    verifyEmail,
    checkEmailVerification,
    resendVerificationEmail
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
} 