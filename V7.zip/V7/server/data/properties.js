const properties = [
    {
        id: 1,
        title: "Modern 3 Bedroom Apartment",
        location: "Gombe",
        price: 5000000,
        type: "Apartment",
        bedrooms: 3,
        bathrooms: 2,
        amenities: ["Swimming Pool", "24/7 Security", "Parking Space"],
        description: "Beautiful modern apartment in a serene environment",
        status: "Available",
        dateAvailable: "2025-02-06"
    },
    {
        id: 2,
        title: "Luxury Villa with Garden",
        location: "Gombe GRA",
        price: 12000000,
        type: "Villa",
        bedrooms: 5,
        bathrooms: 4,
        amenities: ["Garden", "Security", "Garage", "Swimming Pool"],
        description: "Spacious luxury villa with beautiful garden",
        status: "Available",
        dateAvailable: "2025-02-10"
    },
    {
        id: 3,
        title: "Cozy 2 Bedroom Flat",
        location: "Gombe Central",
        price: 3500000,
        type: "Flat",
        bedrooms: 2,
        bathrooms: 1,
        amenities: ["Security", "Parking"],
        description: "Affordable flat in central location",
        status: "Available",
        dateAvailable: "2025-02-06"
    },
    {
        id: 4,
        title: "Commercial Space",
        location: "Gombe Business District",
        price: 8000000,
        type: "Commercial",
        size: "200sqm",
        amenities: ["24/7 Power", "Parking Lot", "Security"],
        description: "Prime commercial space in business district",
        status: "Available",
        dateAvailable: "2025-02-15"
    },
    {
        id: 5,
        title: "Student Apartment",
        location: "Near Gombe University",
        price: 2000000,
        type: "Apartment",
        bedrooms: 1,
        bathrooms: 1,
        amenities: ["Internet", "Security", "Study Area"],
        description: "Perfect for students, close to university",
        status: "Available",
        dateAvailable: "2025-02-06"
    }
];

module.exports = properties;
