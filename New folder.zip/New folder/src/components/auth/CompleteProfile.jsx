import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { doc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { motion } from 'framer-motion';
import { Phone, Building2, Home, Building, Briefcase } from 'lucide-react';
import { toast } from 'react-hot-toast';

const CompleteProfile = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    phone: '',
    accountType: ''
  });

  useEffect(() => {
    console.log('CompleteProfile mounted, currentUser:', currentUser);
    if (!currentUser) {
      console.log('No current user, redirecting to signin');
      navigate('/signin');
      return;
    }
    
    // Check if user already has a complete profile
    const checkProfile = async () => {
      try {
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        if (userDoc.exists() && userDoc.data().profileCompleted) {
          console.log('Profile already completed, redirecting to dashboard');
          navigate('/dashboard');
        }
      } catch (error) {
        console.error('Error checking profile:', error);
      }
    };

    checkProfile();
  }, [currentUser, navigate]);

  const accountTypes = [
    {
      id: 'personal',
      title: 'Home Seeker',
      description: 'Looking to buy, rent, or invest in properties',
      icon: Home,
      color: 'bg-emerald-50 text-emerald-600'
    },
    {
      id: 'agent',
      title: 'Real Estate Agent',
      description: 'Professional real estate agent or property manager',
      icon: Building,
      color: 'bg-blue-50 text-blue-600'
    },
    {
      id: 'developer',
      title: 'Property Developer',
      description: 'Property development and construction company',
      icon: Briefcase,
      color: 'bg-purple-50 text-purple-600'
    }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.phone || !formData.accountType) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);

    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, {
        phone: formData.phone,
        accountType: formData.accountType,
        profileCompleted: true
      });

      toast.success('Profile completed successfully!');
      navigate('/dashboard');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full space-y-8 bg-white p-8 rounded-xl shadow-lg"
      >
        <div>
          <h2 className="text-center text-3xl font-extrabold text-gray-900">
            Complete Your Profile
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Just a few more details to get you started
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-6">
            <div>
              <label className="text-sm font-medium text-gray-700">
                Account Type
              </label>
              <div className="mt-2 space-y-3">
                {accountTypes.map((type) => (
                  <div
                    key={type.id}
                    onClick={() => setFormData({ ...formData, accountType: type.id })}
                    className={`relative flex items-center p-4 cursor-pointer rounded-lg border ${
                      formData.accountType === type.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-500'
                    }`}
                  >
                    <div className={`flex-shrink-0 ${type.color} p-2 rounded-lg`}>
                      <type.icon className="h-6 w-6" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-sm font-medium text-gray-900">
                        {type.title}
                      </h3>
                      <p className="text-sm text-gray-500">{type.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                Phone Number
              </label>
              <div className="mt-1 relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="tel"
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter your phone number"
                />
              </div>
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {loading ? 'Completing Profile...' : 'Complete Profile'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default CompleteProfile; 